/**
 * Adotrip Demo JS
 * Consolidation of all extracted scripts.
 */

// --- 1. External & Global Configurations ---
const PEXELS_API_KEY = 'y6WP5reQNH7abdL2uzdLTyV8pq0kMmF3CHf7ZNkiHo98DXIvORUOBSfi'; // User will add later

// Google Translate Initialization
async function googleTranslateElementInit() {
    await new google.translate.TranslateElement({
        pageLanguage: 'en',
        includedLanguages: 'hi,ta,te,ml,kn,mr,ar,en,ru,id,es,de,fr,tr,it,pt,th,ja',
    }, 'google_translate_element');

    // Add 'notranslate' class to elements you want to exclude from translation
    const elementsToExclude = document.querySelectorAll('.ignore-translate');
    elementsToExclude.forEach((element) => {
        element.classList.add('notranslate');
    });

    const googlebutton = document.getElementsByClassName('goog-te-combo');
    if (googlebutton.length > 0) {
        googlebutton[0].className = 'goog-te-combo ';
    }

    const poweredby = document.getElementsByClassName('skiptranslate goog-te-gadget');
    if (poweredby.length > 0 && poweredby[0].firstChild && poweredby[0].firstChild.nextSibling) {
        poweredby[0].firstChild.nextSibling.remove();
    }

    const logoElements = document.getElementsByClassName('VIpgJd-ZVi9od-l4eHX-hSRGPd');
    if (logoElements.length > 0) {
        logoElements[0].remove();
    }
}

// Meta Pixel Code
!function (f, b, e, v, n, t, s) {
    if (f.fbq) return; n = f.fbq = function () {
        n.callMethod ?
            n.callMethod.apply(n, arguments) : n.queue.push(arguments)
    };
    if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = '2.0';
    n.queue = []; t = b.createElement(e); t.async = !0;
    t.src = v; s = b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t, s)
}(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '317064579831923');
fbq('track', 'PageView');

// Google Tag Manager
(function (w, d, s, l, i) {
    w[l] = w[l] || []; w[l].push({
        'gtm.start': new Date().getTime(),
        event: 'gtm.js'
    });
    var f = d.getElementsByTagName(s)[0],
        j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
    j.async = true; j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
    f.parentNode.insertBefore(j, f);
})(window, document, 'script', 'dataLayer', 'GTM-TXW73RS3');

// --- 2. Helper Functions ---

// Unified Geolocation Logic
function initGeolocation() {
    if (!navigator.geolocation) return;

    navigator.geolocation.getCurrentPosition(function (position) {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;

        fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`)
            .then(res => res.json())
            .then(data => {
                const city = data.address.city || data.address.town || data.address.village || data.address.state || '';
                if (!city) return;

                // Use Case 1: Update localStorage and URL param if missing
                localStorage.setItem('user_city', city);
                const urlParams = new URLSearchParams(window.location.search);
                if (!urlParams.has('citygeo')) {
                    window.location.href = window.location.pathname + "?citygeo=" + encodeURIComponent(city);
                }

                // Use Case 2: Update Flight Airport placeholder
                $.ajax({
                    url: 'https://www.adotrip.com/get-airport-list',
                    method: 'GET',
                    data: { search: city },
                    success: function (results) {
                        if (results && results[0] && results[0].city_name) {
                            $('.fromCityname').attr('placeholder', results[0].city_name);
                        }
                    }
                });

                // Use Case 3: Update Holiday City placeholder
                $.ajax({
                    url: 'https://www.adotrip.com/get-cities-geo',
                    method: 'GET',
                    data: { search: city },
                    success: function (results) {
                        if (results && results[0] && results[0].city) {
                            $('#city-input').attr('placeholder', results[0].city);
                        }
                    }
                });
            });
    });
}

function redirectToCity() {
    const desktopInput = document.getElementById("cityInput");
    const drawerInput = document.getElementById("cityInput-drawer");
    const cityName = (drawerInput && drawerInput.value) || (desktopInput && desktopInput.value);
    
    if (cityName) {
        window.location.href = "https://www.adotrip.com/holiday-packages/" + cityName.toLowerCase().replace(/\s+/g, '-');
    }
    return false;
}

function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
}

// Pexels Gallery Logic
function initPexelsGallery() {
    const locationQuery = $('#location').text().trim() || 'Assi Ghat';
    
    if (!PEXELS_API_KEY || PEXELS_API_KEY === 'YOUR_PEXELS_API_KEY') {
        console.warn('Pexels API key missing. Using placeholder images or existing image.');
        return;
    }

    fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(locationQuery)}&per_page=5&orientation=landscape`, {
        headers: {
            Authorization: PEXELS_API_KEY
        }
    })
    .then(res => res.json())
    .then(data => {
        if (data.photos && data.photos.length > 0) {
            const photos = data.photos;
            const wrapper = $('#thumbnailWrapper');
            wrapper.empty();

            // Set main image to first photo if needed
            $('#mainFeaturedImage').attr('src', photos[0].src.large2x);

            photos.forEach((photo, index) => {
                const isActive = index === 0 ? 'active' : '';
                const thumbHtml = `
                    <div class="swiper-slide" style="width: auto;">
                        <div class="thumbnail-item ${isActive}" data-large="${photo.src.large2x}">
                            <img src="${photo.src.medium}" alt="${photo.alt}">
                        </div>
                    </div>
                `;
                wrapper.append(thumbHtml);
            });

            // Function to calculate and set thumbnail widths
            function updateThumbnailWidths() {
                const containerWidth = $('.gallery-container').width() || $('.thumbnail-swiper-container').width();
if (containerWidth > 0) {

    // Mobile <576px
    if (window.innerWidth < 576) {

        $('.thumbnail-wrapper').css({
            display: 'flex',
            gap: '10px',
            overflowX: 'auto'
        });

        $('.thumbnail-item').css({
width:'100%',
            flex: '0 0 auto'
        });

    } else {

        const gap = 12;
        const itemsPerRow = 5;

        const thumbWidth =
            (containerWidth - (gap * (itemsPerRow - 1))) / itemsPerRow;

        $('.thumbnail-wrapper').css({
            display: 'flex',
            gap: gap + 'px'
        });

        $('.thumbnail-item').css({
            width: thumbWidth + 'px',
            maxWidth: thumbWidth + 'px'
        });
    }
}
            }

            // Initial calculation
            updateThumbnailWidths();
            
            // Update on resize
            $(window).on('resize', updateThumbnailWidths);

            // Initialize Swiper
            const thumbSwiper = new Swiper(".thumbnailSwiper", {
                slidesPerView: 5,
                spaceBetween: 12,
                freeMode: true,
                watchSlidesProgress: true,
                breakpoints: {
                    320: {
                        slidesPerView: 3.5,
                        spaceBetween: 8
                    },
                    768: {
                        slidesPerView: 4.5,
                        spaceBetween: 10
                    },
                    1024: {
                        slidesPerView: 5,
                        spaceBetween: 12
                    }
                }
            });

            // Handle thumbnail click
            $(document).on('click', '.thumbnail-item', function() {
                const largeImg = $(this).data('large');
                const $mainImg = $('#mainFeaturedImage');
                
                $mainImg.css('opacity', '0.5');
                setTimeout(() => {
                    $mainImg.attr('src', largeImg);
                    $mainImg.css('opacity', '1');
                }, 200);

                $('.thumbnail-item').removeClass('active');
                $(this).addClass('active');
            });
        }
    })
    .catch(err => console.error('Error fetching Pexels images:', err));
}

// --- 3. UI Interactions & Event Handlers ---

$(document).ready(function () {
    // --- Smart Sticky Header Logic ---
    let lastScrollTop = 0;
    const $header = $('.smart-sticky-nav');
    const scrollThreshold = 100;

    $(window).scroll(function() {
        let st = $(this).scrollTop();
        
        if (st > 50) {
            $header.addClass('is-scrolled');
        } else {
            $header.removeClass('is-scrolled');
        }

        if (Math.abs(lastScrollTop - st) <= 5) return;

        if (st > lastScrollTop && st > scrollThreshold) {
            $header.addClass('nav-up');
        } else {
            if (st + $(window).height() < $(document).height()) {
                $header.removeClass('nav-up');
            }
        }
        lastScrollTop = st;
    });

    // 1. Language Select Label
    setTimeout(() => {
        const selects = document.querySelectorAll('.goog-te-combo');
        selects.forEach(select => {
            if (select.options.length > 0) {
                select.options[0].text = 'Language';
            }
        });
    }, 800);

    // 2. Newsletter Subscription
    $('#subscribeForm').on('submit', function (e) {
        e.preventDefault();
        let form = $(this);
        $.ajax({
            url: form.attr('action'),
            type: "POST",
            data: form.serialize(),
            success: function (response) {
                $('#subscribeMsg').html('<span style="color:green;">' + response.success + '</span>');
                form[0].reset();
            },
            error: function (xhr) {
                let errorMsg = xhr.status === 422 ? xhr.responseJSON.error : 'Something went wrong.';
                $('#subscribeMsg').html('<span style="color:red;">' + errorMsg + '</span>');
            }
        });
    });

    // 3. Tab Navigation & Scroll
    const eventTabs = document.querySelectorAll('#eventFestivalsDetailTab button[data-bs-toggle="tab"]');
    eventTabs.forEach(tabEl => {
        tabEl.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('data-bs-target');
            const targetPane = document.querySelector(targetId);
            
            if (targetPane) {
                // Manual fallback for class toggling
                document.querySelectorAll('#eventFestivalsDetailTab .nav-link').forEach(btn => btn.classList.remove('active'));
                document.querySelectorAll('#eventFestivalsDetailTabContent .tab-pane').forEach(pane => pane.classList.remove('show', 'active'));
                
                this.classList.add('active');
                targetPane.classList.add('show', 'active');
                
                // Try Bootstrap API
                if (window.bootstrap && bootstrap.Tab) {
                    const tab = bootstrap.Tab.getOrCreateInstance(this);
                    tab.show();
                }
                
                // Update URL hash without jumping
                history.replaceState(null, null, targetId);
            }
        });
    });

    if (window.location.hash) {
        const tabTrigger = document.querySelector('[data-bs-target="' + window.location.hash + '"]');
        if (tabTrigger) {
            if (window.bootstrap && bootstrap.Tab) {
                bootstrap.Tab.getOrCreateInstance(tabTrigger).show();
            } else {
                tabTrigger.click(); // Fallback to manual click
            }
            setTimeout(() => {
                tabTrigger.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 500);
        }
    }

    // 4. Dropdown Menus
    const dropdownItems = document.querySelectorAll('.dropdown-toggle-item');
    dropdownItems.forEach(item => {
        const link = item.querySelector('.menu-link-ttt');
        if (link) {
            link.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                dropdownItems.forEach(otherItem => {
                    if (otherItem !== item) otherItem.classList.remove('active');
                });
                item.classList.toggle('active');
            });
        }
    });

    document.addEventListener('click', function () {
        dropdownItems.forEach(item => item.classList.remove('active'));
    });

    $('.submenu-ttt').on('click', function (e) {
        e.stopPropagation();
    });

    // 5. Go To Top Button
    let mybutton = document.getElementById("goToTopBtn");
    window.onscroll = function () {
        if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
            if (mybutton) mybutton.style.display = "block";
        } else {
            if (mybutton) mybutton.style.display = "none";
        }
    };

    // 6. Autocomplete Setup
    setupAutocomplete('.fromCityname', '#from-city-code', 'from-suggestions');
    setupAutocomplete('.toCityname', '#to-city-code', 'to-suggestions');
    setupDynamicAutocomplete('multi-from-city', 'multi-from-code', 'from-suggestion-box');
    setupDynamicAutocomplete('multi-to-city', 'multi-to-code', 'to-suggestion-box');

    // 7. Hotel Rating
    let savedRating = $('#hotel_rating').val();
    if (savedRating) {
        let starsText = (savedRating === 'All') ? 'All' : '⭐'.repeat(parseInt(savedRating)) + ' ' + savedRating + ' Star';
        $('#ratingDropdown').val(starsText);
    } else {
        $('#ratingDropdown').val('All');
        $('#hotel_rating').val('All');
    }

    $(document).on('click', '.rating-item', function () {
        let rating = $(this).data('rating');
        let starsText = (rating === 'All') ? 'All' : '⭐'.repeat(parseInt(rating));
        $('#ratingDropdown').val(starsText);
        $('#hotel_rating').val(rating);
    });

    // 8. Fare Scroll Swipe Dots
    const fareContainer = document.querySelector('.fare-scroll-container');
    const dots = document.querySelectorAll('.dot');
    if (fareContainer && dots.length > 0) {
        fareContainer.addEventListener('scroll', () => {
            const scrollPercentage = fareContainer.scrollLeft / (fareContainer.scrollWidth - fareContainer.clientWidth);
            const activeIndex = Math.min(Math.floor(scrollPercentage * dots.length), dots.length - 1);
            dots.forEach((dot, index) => dot.classList.toggle('active', index === activeIndex));
        });
    }

    // 9. Fare Scroll Button Navigation
    const fareScroll = document.getElementById('fareScroll');
    if (fareScroll) {
        $('.scroll-btn.left').on('click', () => fareScroll.scrollBy({ left: -200, behavior: 'smooth' }));
        $('.scroll-btn.right').on('click', () => fareScroll.scrollBy({ left: 200, behavior: 'smooth' }));
    }

    // 10. Horizontal Drag Scroll
    const sliders = document.querySelectorAll('.fare-scroll-container');
    sliders.forEach(slider => {
        let isDown = false, startX, scrollLeft, velocity = 0, raf;
        slider.addEventListener('mousedown', (e) => {
            isDown = true;
            slider.classList.add('active');
            startX = e.pageX;
            scrollLeft = slider.scrollLeft;
            cancelAnimationFrame(raf);
        });
        slider.addEventListener('mouseleave', () => isDown = false);
        slider.addEventListener('mouseup', () => {
            isDown = false;
            slider.classList.remove('active');
            function momentum() {
                slider.scrollLeft += velocity;
                velocity *= 0.95;
                if (Math.abs(velocity) > 0.5) raf = requestAnimationFrame(momentum);
            }
            momentum();
        });
        slider.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX;
            const walk = (x - startX);
            velocity = -walk * 0.1;
            slider.scrollLeft = scrollLeft - walk;
        });
    });

    // 11. Flatpickr Initializations
    const depPicker = flatpickr(".dep_date_cls", {
        disableMobile: true,
        dateFormat: "Y-m-d",
        minDate: "today",
        showMonths: 1,
        onChange: function (selectedDates, dateStr) {
            if (selectedDates.length) {
                returnPicker.set("minDate", dateStr);
                if ($("#roundtrip").is(':checked')) {
                    setTimeout(() => document.querySelector(".return_date_cls").focus(), 100);
                }
            }
        }
    });

    const returnPicker = flatpickr(".return_date_cls", {
        disableMobile: true,
        dateFormat: "Y-m-d",
        minDate: "today",
        showMonths: 1
    });

    const checkoutPicker = flatpickr("#checkout", {
        disableMobile: true,
        dateFormat: "Y-m-d",
        minDate: "today"
    });

    flatpickr("#checkin", {
        disableMobile: true,
        dateFormat: "Y-m-d",
        minDate: "today",
        onChange: function (selectedDates) {
            if (selectedDates.length > 0) {
                const nextDay = new Date(selectedDates[0]);
                nextDay.setDate(nextDay.getDate() + 1);
                checkoutPicker.setDate(nextDay);
                checkoutPicker.set("minDate", nextDay);
            }
        }
    });

    // Start Geolocation
    initGeolocation();

    // Initialize Lightbox
    if (typeof GLightbox !== 'undefined') {
        GLightbox({ selector: ".glightbox" });
    }

    // Initialize Pexels Gallery
    initPexelsGallery();

    // Initialize Offers Swiper
    if (typeof Swiper !== 'undefined' && document.querySelector('.offers-swiper')) {
        new Swiper('.offers-swiper', {
            slidesPerView: 1,
            spaceBetween: 20,
            loop: true,
            autoplay: {
                delay: 4000,
                disableOnInteraction: false,
            },
            navigation: {
                nextEl: '.offer-nav-next',
                prevEl: '.offer-nav-prev',
            },
            breakpoints: {
                768: {
                    slidesPerView: 2,
                },
                1200: {
                    slidesPerView: 2,
                }
            }
        });
    }

    // Initialize Attractions Swiper
    if (typeof Swiper !== 'undefined' && document.querySelector('.attractions-swiper')) {
        new Swiper('.attractions-swiper', {
            slidesPerView: 1,
            spaceBetween: 25,
            loop: true,
            navigation: {
                nextEl: '.attraction-next',
                prevEl: '.attraction-prev',
            },
            pagination: {
                el: '.attraction-pagination',
                clickable: true,
                dynamicBullets: true,
            },
            breakpoints: {
                576: {
                    slidesPerView: 1.5,
                },
                768: {
                    slidesPerView: 2.5,
                },
                1024: {
                    slidesPerView: 3,
                }
            }
        });

        // Fetch Pexels images for attractions
        $('.attraction-card').each(function() {
            const $card = $(this);
            const query = $card.data('query');
            const $img = $card.find('.attraction-img');

            if (PEXELS_API_KEY && query) {
                fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=1`, {
                    headers: { Authorization: PEXELS_API_KEY }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.photos && data.photos.length > 0) {
                        $img.attr('src', data.photos[0].src.large);
                    }
                })
                .catch(err => console.error('Error fetching attraction image:', err));
            }
        });

        // Fetch Pexels images for travel cards
        $('.reach-card').each(function() {
            const $card = $(this);
            const query = $card.data('query');
            const $img = $card.find('.reach-img');

            if (PEXELS_API_KEY && query) {
                fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=1`, {
                    headers: { Authorization: PEXELS_API_KEY }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.photos && data.photos.length > 0) {
                        $img.attr('src', data.photos[0].src.large);
                    }
                })
                .catch(err => console.error('Error fetching reach image:', err));
            }
        });
    }

    // Real-time Weather, AQI and Clock
    function initRealTimeData() {
        // Update clock every second
        setInterval(() => {
            const now = new Date();
            const timeString = now.toLocaleTimeString('en-IN', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit', 
                hour12: true 
            });
            $('#realTime').text(timeString);
        }, 1000);

        // Coordinates for Varanasi (Assi Ghat)
        const lat = 25.3176;
        const lon = 82.9739;

        // Fetch Weather
        fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`)
            .then(res => res.json())
            .then(data => {
                if (data.current_weather) {
                    const temp = Math.round(data.current_weather.temperature);
                    const code = data.current_weather.weathercode;
                    const statusMap = {
                        0: 'Clear', 1: 'Mainly Clear', 2: 'Partly Cloudy', 3: 'Overcast',
                        45: 'Fog', 48: 'Depositing Rime Fog', 51: 'Light Drizzle',
                        61: 'Slight Rain', 71: 'Slight Snow', 95: 'Thunderstorm'
                    };
                    const status = statusMap[code] || 'Clear';
                    $('#weatherData').html(`${temp}&deg;C / ${status}`);
                }
            });

        // Fetch AQI
        fetch(`https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&current=us_aqi`)
            .then(res => res.json())
            .then(data => {
                if (data.current && data.current.us_aqi) {
                    const aqi = data.current.us_aqi;
                    let quality = 'Good';
                    let color = '#28a745'; // green
                    if (aqi > 50) { quality = 'Moderate'; color = '#ffc107'; }
                    if (aqi > 100) { quality = 'Unhealthy'; color = '#dc3545'; }
                    
                    $('#aqiData').text(`${aqi} (${quality})`).css('color', color);
                }
            });
    }

    initRealTimeData();

    // --- Mobile Drawer Logic ---
    const $mobileDrawer = $('#luxMobileSideDrawer');
    const $mobileOverlay = $('#luxMobileDrawerOverlay');
    const $mobileNavBtns = $('.lux-mobile-nav-btn');
    const $drawerModules = $('#luxMobileSideDrawer .lux-sidebar-card');

    $mobileNavBtns.on('click', function() {
        const targetId = $(this).data('target');
        
        // Open drawer
        $mobileDrawer.addClass('active');
        $mobileOverlay.addClass('active');
        $('body').css('overflow', 'hidden');

        // Switch module
        $drawerModules.hide();
        $(`#${targetId}`).fadeIn(300);
    });

    function closeMobileDrawer() {
        $mobileDrawer.removeClass('active');
        $mobileOverlay.removeClass('active');
        $('body').css('overflow', '');
    }

    $('#luxMobileDrawerClose, #luxMobileDrawerOverlay').on('click', closeMobileDrawer);

    $(document).on('keydown', function(e) {
        if (e.key === 'Escape') closeMobileDrawer();
    });
});

// --- 4. Core Autocomplete Logic ---

function setupAutocomplete(inputSelector, hiddenInputSelector, suggestionId) {
    const $input = $(inputSelector);
    if (!$input.length) return;

    const $hiddenInput = $(hiddenInputSelector);
    const $suggestions = $('<div>', { id: suggestionId, class: 'list-group' }).css({
        position: 'absolute', zIndex: 1000, width: $input.outerWidth()
    }).hide().insertAfter($input);

    $input.on('keyup', function () {
        const query = $(this).val();
        $.ajax({
            url: 'https://www.adotrip.com/get-airport-list',
            method: 'GET',
            data: { search: query },
            success: function (data) {
                $suggestions.empty();
                if (!data.length) { $suggestions.hide(); return; }
                data.forEach(item => {
                    const html = `<div class="list-group-item city-item" data-city="${item.city_name}" data-code="${item.ac}">
                        <i class="fas fa-map-marker-alt"></i> ${item.city_name} <small class="text-muted">(${item.ac}) ${item.airport_name}</small>
                    </div>`;
                    $suggestions.append(html);
                });
                $suggestions.show();
            }
        });
    });

    $suggestions.on('click', '.city-item', function () {
        const city = $(this).data('city');
        const code = $(this).data('code');
        $input.val(city);
        $hiddenInput.val(code);
        $suggestions.empty().hide();
        if (hiddenInputSelector === '#to-city-code') sendCityData();
    });

    $(document).on('click', e => {
        if (!$(e.target).closest(inputSelector + ', #' + suggestionId).length) $suggestions.empty().hide();
    });
}

function setupDynamicAutocomplete(inputClass, hiddenClass, suggestionBoxClass) {
    $('.' + suggestionBoxClass).remove();
    $('body').on('focus click keyup', '.' + inputClass, function () {
        const $input = $(this);
        const query = $input.val();
        let $suggestions = $input.data('suggestions');
        if (!$suggestions) {
            $suggestions = $('<div>', { class: suggestionBoxClass + ' list-group' }).css({
                position: 'absolute', zIndex: 1000, width: $input.outerWidth()
            }).hide();
            $('body').append($suggestions);
            $input.data('suggestions', $suggestions);
        }
        const offset = $input.offset();
        $suggestions.css({ top: offset.top + $input.outerHeight(), left: offset.left });

        $.ajax({
            url: 'https://www.adotrip.com/get-airport-list',
            method: 'GET',
            data: { search: query },
            success: function (data) {
                $suggestions.empty();
                if (!data.length) { $suggestions.hide(); return; }
                data.forEach(item => {
                    const html = `<div class="list-group-item city-item" data-city="${item.city_name}" data-code="${item.ac}">
                        <i class="fas fa-map-marker-alt"></i> ${item.city_name} <small class="text-muted">(${item.ac})</small>
                    </div>`;
                    $suggestions.append(html);
                });
                $suggestions.show();
            }
        });

        $suggestions.off('click').on('click', '.city-item', function () {
            const city = $(this).data('city');
            const code = $(this).data('code');
            $input.val(city);
            $input.siblings('.' + hiddenClass).val(code);
            $suggestions.empty().hide();
        });
    });
}

function sendCityData() {
    const from = $('#from-city-code').val(), to = $('#to-city-code').val();
    if (from && to) {
        $.ajax({
            url: 'https://www.adotrip.com/get-calendar-fare',
            method: 'GET',
            data: { fromCityCode: from, toCityCode: to },
            success: function (response) { initializeCalendar(response); }
        });
    }
}

function initializeCalendar(results) {
    const priceData = {};
    results.forEach(item => {
        const date = item.DepartureDate.split("T")[0];
        if (!priceData[date] || item.Fare < priceData[date]) priceData[date] = Math.round(item.Fare);
    });

    flatpickr(".dep_date_cls", {
        disableMobile: true, dateFormat: "Y-m-d", minDate: "today", showMonths: 1,
        onDayCreate: (dObj, dStr, fp, dayElem) => {
            const date = fp.formatDate(dayElem.dateObj, "Y-m-d");
            if (priceData[date]) {
                const priceSpan = document.createElement("span");
                priceSpan.innerHTML = "INR" + priceData[date];
                priceSpan.style.cssText = "display:block; font-size:10px; color:#28a745; margin-top:-22px;";
                dayElem.appendChild(priceSpan);
            }
        }
    });
}

// Single selection for Lux Fare Grid Checkboxes
document.addEventListener('DOMContentLoaded', function() {
    const fareCheckboxes = document.querySelectorAll('.lux-fare-grid input[type="checkbox"]');
    fareCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            if (this.checked) {
                fareCheckboxes.forEach(cb => {
                    if (cb !== this) cb.checked = false;
                });
            }
        });
    });
    // Load Holiday Packages dynamically
    loadHolidayPackages();

    // Load Holiday Packages dynamically
    loadHolidayPackages();
});

let allHolidayPackages = [];
const packagesPerPage = 6;
let currentHolidayPage = 1;

async function loadHolidayPackages() {
    const container = document.getElementById('holidayPackagesContainer');
    if (!container) return;

    try {
        const response = await fetch('tour_packages.json');
        allHolidayPackages = await response.json();
        renderHolidayPage(1);
    } catch (error) {
        console.error('Error loading tour packages:', error);
        container.innerHTML = '<div class="col-12"><p class="text-center py-5">Unable to load holiday packages at this time.</p></div>';
    }
}

function renderHolidayPage(page) {
    const container = document.getElementById('holidayPackagesContainer');
    if (!container) return;

    currentHolidayPage = page;
    const start = (page - 1) * packagesPerPage;
    const end = start + packagesPerPage;
    const paginatedItems = allHolidayPackages.slice(start, end);

    container.innerHTML = paginatedItems.map(pkg => createHolidayCard(pkg)).join('');
    renderHolidayPagination();
    
    // Scroll to top of container smoothly
    container.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderHolidayPagination() {
    const totalPages = Math.ceil(allHolidayPackages.length / packagesPerPage);
    const paginationContainer = document.getElementById('holidayPagination');
    if (!paginationContainer) return;

    let paginationHtml = '';
    
    // Previous button
    paginationHtml += `
        <li class="page-item ${currentHolidayPage === 1 ? 'disabled' : ''}">
            <a class="page-link" href="javascript:void(0)" onclick="renderHolidayPage(${currentHolidayPage - 1})">
                <i class="ph ph-caret-left"></i>
            </a>
        </li>
    `;

    // Page numbers (limited to 5 for clean UI)
    let startPage = Math.max(1, currentHolidayPage - 2);
    let endPage = Math.min(totalPages, startPage + 4);
    if (endPage - startPage < 4) startPage = Math.max(1, endPage - 4);

    for (let i = startPage; i <= endPage; i++) {
        paginationHtml += `
            <li class="page-item ${currentHolidayPage === i ? 'active' : ''}">
                <a class="page-link" href="javascript:void(0)" onclick="renderHolidayPage(${i})">${i}</a>
            </li>
        `;
    }

    // Next button
    paginationHtml += `
        <li class="page-item ${currentHolidayPage === totalPages ? 'disabled' : ''}">
            <a class="page-link" href="javascript:void(0)" onclick="renderHolidayPage(${currentHolidayPage + 1})">
                <i class="ph ph-caret-right"></i>
            </a>
        </li>
    `;

    paginationContainer.innerHTML = paginationHtml;
}

function createHolidayCard(pkg) {
    const inclusionIcons = {
        'Hotel': 'ph ph-buildings',
        'Transport': 'ph ph-car',
        'Meals': 'ph ph-fork-knife',
        'Sightseeing': 'ph ph-binoculars',
        'Transfer': 'ph ph-van'
    };

    const iconsHtml = pkg.inclusions.map(inc => {
        const iconClass = inclusionIcons[inc] || 'ph ph-check-circle';
        return `<span class="inclusion-tag" title="${inc} Included"><i class="${iconClass}"></i> ${inc}</span>`;
    }).join('');

    return `
        <div class="col-lg-6 mb-4">
            <div class="lux-holiday-card">
                <div class="card-image-wrapper">
                    <img src="${pkg.image || 'https://via.placeholder.com/600x400?text=Premium+Tour'}" alt="${pkg.title}" />
                    <div class="card-overlay">
                        <span class="nights-badge"><i class="ph ph-moon"></i> ${pkg.nights} Nights</span>
                    </div>
                </div>
                <div class="card-content-wrapper">
                    <div class="card-meta">
                        <span class="location-tag"><i class="ph ph-map-pin-fill"></i> ${pkg.location}</span>
                    </div>
                    <h3 class="card-title">${pkg.title}</h3>
                    <div class="inclusion-list">
                        ${iconsHtml}
                    </div>
                    <div class="card-footer-action">
                        <div class="price-block">
                            <span class="price-label">Exclusively From</span>
                            <div class="price-value">
                                <span class="currency">₹</span>
                                <span class="amount">${pkg.discounted_price.toLocaleString()}</span>
                                <span class="original-price">₹${pkg.original_price.toLocaleString()}</span>
                            </div>
                            <span class="price-note">${pkg.pricing_basis}</span>
                        </div>
                        <a href="${pkg.url}" class="lux-view-btn">
                            Explore <i class="ph ph-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    `;
}