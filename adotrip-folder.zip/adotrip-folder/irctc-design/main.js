
const PEXELS_KEY = 'BpSNnI6B3EFZdYcELMmIUWb8dXSIbHDZ0gQfmI8Zu9JnlAhIxIIakY5J';

const destinations = [
  { name: 'Goa', query: 'Goa India beach' },
  { name: 'Manali', query: 'Manali Himachal Pradesh mountains' },
  { name: 'Kerala', query: 'Kerala backwaters India' },
  { name: 'Rajasthan', query: 'Jaipur Rajasthan palace' },
  { name: 'Andaman', query: 'Andaman islands beach tropical' },
  { name: 'Leh Ladakh', query: 'Leh Ladakh mountain landscape' },
  { name: 'Bali', query: 'Bali Indonesia temple' },
  { name: 'Singapore', query: 'Singapore skyline night' },
  { name: 'Dubai', query: 'Dubai city skyline' },
  { name: 'Paris', query: 'Paris Eiffel Tower' },
];

const packages = [
  { name: 'Goa Beach Escape', duration: '4N/5D', price: '₹24,999', rating: '4.7', reviews: '2.3k', inclusions: 'Flight + Hotel + Breakfast', query: 'Goa beach resort', badge: 'Popular', badgeColor: 'bg-red-100 text-red-700' },
  { name: 'Kerala Backwaters', duration: '5N/6D', price: '₹32,499', rating: '4.8', reviews: '1.8k', inclusions: 'Hotel + Houseboat + Meals', query: 'Kerala houseboat backwaters', badge: 'Best Seller', badgeColor: 'bg-green-100 text-green-700' },
  { name: 'Manali Adventure', duration: '6N/7D', price: '₹28,999', rating: '4.6', reviews: '3.1k', inclusions: 'Hotel + Transfers + Activities', query: 'Manali snow mountain winter', badge: 'Adventure', badgeColor: 'bg-blue-100 text-blue-700' },
  { name: 'Rajasthan Heritage', duration: '7N/8D', price: '₹35,999', rating: '4.9', reviews: '4.2k', inclusions: 'Hotel + Guide + Entry Tickets', query: 'Rajasthan fort palace heritage', badge: 'Cultural', badgeColor: 'bg-yellow-100 text-yellow-700' },
  { name: 'Bali Honeymoon', duration: '5N/6D', price: '₹62,999', rating: '4.8', reviews: '2.7k', inclusions: 'Flights + Villa + Couples Spa', query: 'Bali honeymoon villa pool', badge: 'Honeymoon', badgeColor: 'bg-pink-100 text-pink-700' },
  { name: 'Singapore Explorer', duration: '4N/5D', price: '₹54,999', rating: '4.7', reviews: '1.5k', inclusions: 'Flights + Hotel + City Tour', query: 'Singapore Gardens by Bay', badge: 'International', badgeColor: 'bg-purple-100 text-purple-700' },
];

const hotels = [
  { name: 'The Leela Palace', location: 'New Delhi', rating: '5.0', reviews: '4.2k', price: '₹12,499', originalPrice: '₹18,000', category: 'Luxury', query: 'luxury hotel palace lobby', amenities: ['Pool', 'Spa', 'Free WiFi', 'Restaurant', 'Gym'] },
  { name: 'Taj Exotica Resort', location: 'Goa', rating: '4.9', reviews: '3.8k', price: '₹8,999', originalPrice: '₹13,500', category: 'Beach Resort', query: 'beach resort pool Goa', amenities: ['Beach Access', 'Pool', 'Bar', 'Yoga', 'Free Breakfast'] },
  { name: 'The Oberoi Udaivilas', location: 'Udaipur', rating: '4.9', reviews: '2.1k', price: '₹22,499', originalPrice: '₹30,000', category: 'Heritage', query: 'Udaipur lake palace heritage hotel', amenities: ['Lake View', 'Spa', 'Infinity Pool', 'Butler'] },
];

const exploreItems = [
  { title: 'Guide: Best Time to Visit Goa', tag: 'Travel Guide', query: 'Goa beach sunset travel' },
  { title: 'Top 10 Hill Stations Near Delhi', tag: 'Listicle', query: 'hill station mountains fog India' },
  { title: 'International Trips Under ₹50K', tag: 'Budget Travel', query: 'Southeast Asia travel budget backpack' },
  { title: 'Monsoon Destinations You Must See', tag: 'Seasonal', query: 'monsoon India waterfall nature green' },
];

async function fetchPexels(query, perPage = 1) {
  const r = await fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=${perPage}&orientation=landscape`, {
    headers: { Authorization: PEXELS_KEY }
  });
  const d = await r.json();
  return d.photos && d.photos.length ? d.photos[0].src.medium : 'https://images.pexels.com/photos/1285625/pexels-photo-1285625.jpeg?auto=compress&cs=tinysrgb&w=600';
}

async function loadTrending() {
  const grid = document.getElementById('trending-grid');
  for (const dest of destinations) {
    const card = document.createElement('div');
    card.className = 'relative rounded-2xl overflow-hidden cursor-pointer card-hover group';
    card.style.height = '180px';
    card.innerHTML = `<div class="w-full h-full bg-gray-200 animate-pulse"></div>`;
    grid.appendChild(card);
    fetchPexels(dest.query).then(url => {
      card.innerHTML = `
        <img src="${url}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="${dest.name}"/>
        <div class="absolute inset-0 bg-black/35 group-hover:bg-black/25 transition-colors"></div>
        <div class="absolute bottom-0 left-0 right-0 p-3">
          <div class="text-white font-bold text-sm">${dest.name}</div>
        </div>`;
    });
  }
}

async function loadPackages() {
  const grid = document.getElementById('packages-grid');
  for (const pkg of packages) {
    const card = document.createElement('div');
    card.className = 'bg-white rounded-2xl overflow-hidden border border-gray-100 card-hover';
    card.innerHTML = `<div class="w-full h-48 bg-gray-200 animate-pulse"></div>
      <div class="p-5">
        <div class="flex items-center justify-between mb-2">
          <span class="text-xs ${pkg.badgeColor} px-2 py-1 rounded-full font-semibold">${pkg.badge}</span>
          <div class="flex items-center gap-1"><span class="text-yellow-400 text-xs">★</span><span class="text-xs font-semibold">${pkg.rating}</span><span class="text-xs text-gray-400">(${pkg.reviews})</span></div>
        </div>
        <div class="font-bold text-gray-900 text-base mb-1">${pkg.name}</div>
        <div class="text-xs text-gray-500 mb-3">📅 ${pkg.duration} · ${pkg.inclusions}</div>
        <div class="flex items-center justify-between">
          <div><span class="text-lg font-bold text-gray-900">${pkg.price}</span><span class="text-xs text-gray-400 ml-1">per person</span></div>
          <button class="bg-red-500 text-white text-xs px-4 py-2 rounded-lg hover:bg-red-600 transition-colors font-medium">View →</button>
        </div>
      </div>`;
    grid.appendChild(card);
    fetchPexels(pkg.query).then(url => {
      const img = document.createElement('img');
      img.src = url; img.alt = pkg.name;
      img.className = 'w-full h-48 object-cover';
      card.replaceChild(img, card.querySelector('div'));
    });
  }
}

async function loadHotels() {
  const grid = document.getElementById('hotels-grid');
  for (const hotel of hotels) {
    const card = document.createElement('div');
    card.className = 'bg-white rounded-2xl overflow-hidden border border-gray-100 card-hover';
    const amenityBadges = hotel.amenities.map(a => `<span class="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">${a}</span>`).join('');
    card.innerHTML = `<div class="w-full h-52 bg-gray-200 animate-pulse"></div>
      <div class="p-5">
        <div class="flex items-center justify-between mb-1">
          <span class="text-xs text-blue-600 font-semibold">${hotel.category}</span>
          <div class="flex items-center gap-1"><span class="text-yellow-400 text-xs">★</span><span class="text-xs font-semibold">${hotel.rating}</span><span class="text-xs text-gray-400">(${hotel.reviews})</span></div>
        </div>
        <div class="font-bold text-gray-900 text-base mb-1">${hotel.name}</div>
        <div class="text-xs text-gray-500 mb-3">📍 ${hotel.location}</div>
        <div class="flex flex-wrap gap-1.5 mb-4">${amenityBadges}</div>
        <div class="flex items-center justify-between pt-3 border-t border-gray-100">
          <div>
            <span class="text-xs text-gray-400 line-through block">${hotel.originalPrice}</span>
            <span class="text-lg font-bold text-gray-900">${hotel.price}</span>
            <span class="text-xs text-gray-400">/night</span>
          </div>
          <button class="bg-gray-900 text-white text-xs px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors font-medium">Select Room</button>
        </div>
      </div>`;
    grid.appendChild(card);
    fetchPexels(hotel.query).then(url => {
      const img = document.createElement('img');
      img.src = url; img.alt = hotel.name;
      img.className = 'w-full h-52 object-cover';
      card.replaceChild(img, card.querySelector('div'));
    });
  }
}

async function loadExplore() {
  const grid = document.getElementById('explore-grid');
  for (const item of exploreItems) {
    const card = document.createElement('div');
    card.className = 'rounded-2xl overflow-hidden cursor-pointer card-hover relative group';
    card.style.height = '220px';
    card.innerHTML = `<div class="w-full h-full bg-gray-200 animate-pulse"></div>`;
    grid.appendChild(card);
    fetchPexels(item.query).then(url => {
      card.innerHTML = `
        <img src="${url}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="${item.title}"/>
        <div class="absolute inset-0 bg-black/50 group-hover:bg-black/40 transition-colors"></div>
        <div class="absolute inset-0 flex flex-col justify-end p-4">
          <span class="text-xs bg-red-500 text-white px-2 py-0.5 rounded-full w-fit mb-2">${item.tag}</span>
          <div class="text-white font-semibold text-sm leading-tight">${item.title}</div>
          <div class="text-gray-300 text-xs mt-1 group-hover:text-white transition-colors">Read more →</div>
        </div>`;
    });
  }
}

function setCategory(cat, btn, heroUrl) {
  document.querySelectorAll('.category-tab').forEach(t => {
    t.classList.remove('active', 'bg-red-500');
    t.classList.add('bg-white/10');
  });
  btn.classList.add('active');
  btn.classList.remove('bg-white/10');
  
  document.querySelectorAll('[id^="form-"]').forEach(f => {
    f.classList.add('hidden');
    f.classList.remove('fade-in');
  });
  const form = document.getElementById('form-' + cat);
  if (form) {
    form.classList.remove('hidden');
    setTimeout(() => form.classList.add('fade-in'), 10);
  }
  
  const img = document.getElementById('hero-img');
  img.style.opacity = '0';
  setTimeout(() => {
    img.src = heroUrl;
    img.style.opacity = '1';
  }, 300);
}

function swapCities() {
  const fromEl = document.querySelector('#form-flights .grid .border:nth-child(1) .font-bold');
  const toEl = document.querySelector('#form-flights .grid .border:nth-child(3) .font-bold');
  if (fromEl && toEl) {
    const tmp = fromEl.textContent;
    fromEl.textContent = toEl.textContent;
    toEl.textContent = tmp;
  }
}

loadTrending();
loadPackages();
loadHotels();
loadExplore();