const PEXELS_KEY = typeof ENV !== 'undefined' ? ENV.PEXELS_API_KEY : '';

const destinations = [
  { name: 'Kashmir', query: 'Kashmir mountains lake snow India', desc: 'Switzerland of India' },
  { name: 'Maldives', query: 'Maldives beach resort luxury overwater villa', desc: 'Tropical Paradise' },
  { name: 'Bali', query: 'Bali temple tropical jungle beach', desc: 'Island of the Gods' },
  { name: 'Leh Ladakh', query: 'Ladakh landscape mountains lake', desc: 'Land of High Passes' },
  { name: 'Switzerland', query: 'Switzerland alps mountains village valley', desc: 'Alpine Wonderland' },
];

const packages = [
  { name: 'Goa Beach Escape', duration: '4N/5D', price: '₹24,999', rating: '4.7', reviews: '2.3k', inclusions: 'Flight + Hotel + Breakfast', query: 'Goa beach resort', badge: 'Popular', badgeColor: 'bg-red-100 text-red-700' },
  { name: 'Kerala Backwaters', duration: '5N/6D', price: '₹32,499', rating: '4.8', reviews: '1.8k', inclusions: 'Hotel + Houseboat + Meals', query: 'Kerala houseboat backwaters', badge: 'Best Seller', badgeColor: 'bg-green-100 text-green-700' },
  { name: 'Manali Adventure', duration: '6N/7D', price: '₹28,999', rating: '4.6', reviews: '3.1k', inclusions: 'Hotel + Transfers + Activities', query: 'Manali snow mountain winter', badge: 'Adventure', badgeColor: 'bg-blue-100 text-blue-700' },
  { name: 'Rajasthan Heritage', duration: '7N/8D', price: '₹35,999', rating: '4.9', reviews: '4.2k', inclusions: 'Hotel + Guide + Entry Tickets', query: 'Rajasthan fort palace heritage', badge: 'Cultural', badgeColor: 'bg-yellow-100 text-yellow-700' },
  { name: 'Bali Honeymoon', duration: '5N/6D', price: '₹62,999', rating: '4.8', reviews: '2.7k', inclusions: 'Flights + Villa + Couples Spa', query: 'Bali honeymoon villa pool', badge: 'Honeymoon', badgeColor: 'bg-pink-100 text-pink-700' },
  { name: 'Singapore Explorer', duration: '4N/5D', price: '₹54,999', rating: '4.7', reviews: '1.5k', inclusions: 'Flights + Hotel + City Tour', query: 'Singapore Gardens by Bay', badge: 'International', badgeColor: 'bg-purple-100 text-purple-700' },
];

const irctcSpecials = [
  {
    tab: 'pilgrimage',
    title: "PURI GANGASAGAR-AYODHYA DHAM YATRA",
    duration: "10 Nights/11 Days",
    code: "NZBG74",
    origin: "Pathankot / Amritsar / Jalandhar / Ludhiana / Chandigarh / Delhi / Mathura / Agra / Kanpur",
    destination: "Puri / Kolkata / Jasidih / Gaya / Varanasi / Ayodhya",
    departure: "23.05.2026",
    price: 28270,
    inclusions: ["train", "bus", "hotel", "utensils", "shield-check", "users"],
    query: "Puri Jagannath temple Kolkata Varanasi"
  },
  {
    tab: 'pilgrimage',
    title: "DIVYA DAKSHIN YATRA WITH ARUNACHALAM – CHIDAMBARAM",
    duration: "7 Nights/8 Days",
    code: "SCZBG58",
    origin: "Secunderabad / Hyderabad / Kazipet / Vijayawada / Tenali / Ongole / Nellore / Renigunta",
    destination: "Arunachalam / Rameshwaram / Madurai / Kanniyakumari / Trichy / Chidambaram",
    departure: "24.05.2026",
    price: 14500,
    inclusions: ["train", "bus", "hotel", "utensils", "shield-check", "users"],
    query: "Rameshwaram temple Madurai Kanniyakumari"
  },
  {
    tab: 'pilgrimage',
    title: "07 JYOTIRLINGA YATRA",
    duration: "11 Nights/12 Days",
    code: "NZBG75",
    origin: "Delhi Safdarjung / Gurgaon / Rewari / Alwar / Mathura / Agra / Gwalior / Jhansi",
    destination: "Ujjain / Dwarka / Somnath / Nasik / Pune / Grishneshwar",
    departure: "28.05.2026",
    price: 23505,
    inclusions: ["train", "bus", "hotel", "utensils", "users"],
    query: "Somnath temple Dwarka Ujjain"
  },
  {
    tab: 'pilgrimage',
    title: "AYODHYA KASHI PUNYA KSHETRA YATRA WITH BAIDYANATH DHAM",
    duration: "9 Nights/10 Days",
    code: "SCZBG59",
    origin: "Secunderabad / Kazipet / Vijayawada / Rajahmundry / Samalkot / Duvvada / Vizianagaram",
    destination: "Puri / Konark / Baidyanath / Varanasi / Ayodhya / Prayagraj",
    departure: "03.06.2026",
    price: 16700,
    inclusions: ["train", "bus", "hotel", "utensils", "shield-check", "users"],
    query: "Ayodhya temple Varanasi Ghats"
  },
  {
    tab: 'pilgrimage',
    title: "02 JYOTIRLINGA WITH DAKSHIN DARSHAN YATRA",
    duration: "10 Nights/11 Days",
    code: "WZBG69",
    origin: "Indore / Ujjain / Rani Kamlapati / Itarsi / Nagpur",
    destination: "Tirupati / Rameshwaram / Madurai / Kanniyakumari / Mallikarjun",
    departure: "10.06.2026",
    price: 20250,
    inclusions: ["train", "bus", "hotel", "utensils", "shield-check", "users"],
    query: "Tirupati temple Rameshwaram"
  },
  {
    tab: 'pilgrimage',
    title: "7 JYOTIRLINGA YATRA EX YNRK",
    duration: "11 Nights/12 Days",
    code: "NZBG78",
    origin: "Yog Nagri Rishikesh / Haridwar / Moradabad / Bareilly / Lucknow / Kanpur / Jhansi",
    destination: "Ujjain / Dwarka / Veraval / Nasik Road / Aurangabad",
    departure: "12.06.2026",
    price: 24100,
    inclusions: ["train", "bus", "hotel", "utensils", "shield-check", "users"],
    query: "Dwarka temple Ujjain Mahakal"
  },
  {
    tab: 'pilgrimage',
    title: "SAPTA (07) JYOTIRLINGA DARSHAN YATRA",
    duration: "10 Nights/11 Days",
    code: "SCZBG61",
    origin: "Secunderabad / Nizamabad / Mudkhed / Nanded / Purna / Hyderabad",
    destination: "Ujjain / Dwarka / Somnath / Pune / Nasik / Chhatrapati Sambhajinagar",
    departure: "16.06.2026",
    price: 17600,
    inclusions: ["train", "bus", "hotel", "utensils", "shield-check", "users"],
    query: "Ujjain temple Somnath Dwarka"
  },
  {
    tab: 'pilgrimage',
    title: "PURI KAMAKHYA BAIDYANATH DHAM YATRA",
    duration: "11 Nights/12 Days",
    code: "WZBG70",
    origin: "Pune / Kalyan / Nasik / Bhusaval / Akola / Nagpur",
    destination: "Puri / Guwahati / Jasidih / Varanasi / Ayodhya",
    departure: "25.06.2026",
    price: 22770,
    inclusions: ["train", "bus", "hotel", "utensils", "users"],
    query: "Kamakhya temple Guwahati Puri"
  },
  {
    tab: 'pilgrimage',
    title: "DAKSHIN BHARAT YATRA",
    duration: "11 Nights/12 Days",
    code: "NZBG79",
    origin: "Yog Nagri Rishikesh / Haridwar / Lucknow / Prayagraj / Manikpur",
    destination: "Tirumala / Rameshwaram / Madurai / Kanniyakumari / Srisailam",
    departure: "29.06.2026",
    price: 24350,
    inclusions: ["train", "bus", "hotel", "utensils", "shield-check", "users"],
    query: "Madurai Meenakshi temple Kanyakumari"
  },
  {
    tab: 'pilgrimage',
    title: "AYODHYA- KASHI: PUNYA KSHETRA YATRA WITH BAIDYANATH DHAM",
    duration: "9 Nights/10 Days",
    code: "SCZBG62",
    origin: "Secunderabad / Kazipet / Vijayawada / Rajahmundry / Duvvada / Vizianagram",
    destination: "Gaya / Varanasi / Ayodhya / Prayagraj / Baidyanath",
    departure: "04.07.2026",
    price: 16400,
    inclusions: ["train", "bus", "hotel", "utensils", "shield-check"],
    query: "Varanasi Ganga sunset ghat Ayodhya"
  },
  {
    tab: 'pilgrimage',
    title: "05 JYOTIRLINGA YATRA WITH DWARKADHISH TEMPLE & ELLORA",
    duration: "10 Nights/11 Days",
    code: "WZBG71",
    origin: "Rewa / Satna / Jabalpur / Itarsi / Rani Kamlapati / Ujjain",
    destination: "Somnath / Bhimshankar / Triambakeshwar / Grishneshwar / Ellora",
    departure: "11.07.2026",
    price: 20250,
    inclusions: ["train", "bus", "hotel", "utensils", "shield-check"],
    query: "Ellora caves Somnath temple"
  },
  {
    tab: 'pilgrimage',
    title: "DAKSHIN BHARAT YATRA",
    duration: "12 Nights/13 Days",
    code: "EZBG31",
    origin: "Dumka / Hansdiha / Bhagalpur / Sultanganj / Kiul",
    destination: "Rameshwaram / Madurai / Kanyakumari / Tirupati / Mallikarjun",
    departure: "14.07.2026",
    price: 25400,
    inclusions: ["train", "bus", "hotel", "utensils", "shield-check"],
    query: "Tirupati temple Rameshwaram Kanyakumari"
  },
  {
    tab: 'pilgrimage',
    title: "DIVYA DAKSHIN YATRA EX MANMAD",
    duration: "10 Nights/11 Days",
    code: "WZBG73",
    origin: "Manmad / Nasik / Pune / Miraj / Igatpuri / Kalyan",
    destination: "Hampi / Mysore / Coimbatore / Tiruvannamalai / Vellore / Tirupati / Mallikarjun",
    departure: "27.07.2026",
    price: 19770,
    inclusions: ["train", "bus", "hotel", "utensils", "users"],
    query: "Hampi ruins Mysore palace"
  },
  {
    tab: 'international',
    title: "PASHUPATINATH (NEPAL) DARSHAN YATRA",
    duration: "9 Nights/10 Days",
    code: "WZDBG03",
    origin: "INDORE / UJJAIN / SHUJALPUR / SEHORE / RANI KAMLAPATI / ITARSI / NARSINGPUR / JABALPUR / KATNI / SATNA",
    destination: "CHITWAN NATIONAL PARK / POKHARA / MANAKAMANA / KATHMANDU",
    departure: "12.06.2026",
    price: 61340,
    inclusions: ["train", "bus", "hotel", "utensils", "shield-check"],
    query: "Pashupatinath Kathmandu temple Pokhara Nepal"
  },
  {
    tab: 'international',
    title: "SOUTH INDIA MONSOON MAGIC",
    duration: "13 Nights/14 Days",
    code: "CDBG40",
    origin: "DELHI SAFDARJUNG / MATHURA / AGRA / GWALIOR / JHANSI / BINA / BHOPAL / ITARSI",
    destination: "HAMPI / MYSURU / OOTY / COIMBATORE / KANYAKUMARI / TRIVANDRUM / COCHIN / ALLEPPEY / MURUDESWAR",
    departure: "25.06.2026",
    price: 104640,
    inclusions: ["train", "bus", "hotel", "utensils", "users", "shield-check"],
    query: "Murudeshwar temple Hampi Ooty Kanyakumari"
  }
];

const HotelSearch = {
  API_KEY: typeof ENV !== 'undefined' ? ENV.SERP_API_KEY : '',
  PROXY: 'https://corsproxy.io/?',
};

// ─── SerpApi Data Fetching ─────────────────────────────────────────────────────

async function fetchHotels(location = 'Mumbai', checkIn = '2026-06-20', checkOut = '2026-06-25') {
  const params = new URLSearchParams({
    engine: 'google_hotels',
    q: location,
    check_in_date: checkIn,
    check_out_date: checkOut,
    api_key: HotelSearch.API_KEY,
    num: 20
  });

  try {
    const targetUrl = `https://serpapi.com/search.json?${params.toString()}`;
    const response = await fetch(`${HotelSearch.PROXY}${targetUrl}`);
    const data = await response.json();
    return data.properties || [];
  } catch (error) {
    console.error('Error fetching hotels:', error);
    return [];
  }
}

async function fetchPackages(query = 'Holiday Packages Goa') {
  const params = new URLSearchParams({
    engine: 'google_hotels',
    q: query,
    check_in_date: '2026-06-15',
    check_out_date: '2026-06-20',
    api_key: HotelSearch.API_KEY,
    num: 6
  });

  try {
    const targetUrl = `https://serpapi.com/search.json?${params.toString()}`;
    const response = await fetch(`${HotelSearch.PROXY}${targetUrl}`);
    const data = await response.json();
    return data.properties || [];
  } catch (error) {
    console.error('Error fetching packages:', error);
    return [];
  }
}

async function fetchFlightDeals(from = 'DEL', to = 'BOM') {
  const params = new URLSearchParams({
    engine: 'google_flights',
    departure_id: from,
    arrival_id: to,
    outbound_date: '2026-06-20',
    type: '2',
    currency: 'INR',
    api_key: HotelSearch.API_KEY
  });

  try {
    const url = `https://serpapi.com/search.json?${params.toString()}`;
    const response = await fetch(`${HotelSearch.PROXY}${url}`);
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`SerpApi Flight Error (${response.status}):`, errorText);
      return null;
    }
    const data = await response.json();
    return {
      route: `${from} → ${to}`,
      data: data.best_flights?.[0] || data.other_flights?.[0]
    };
  } catch (error) {
    console.error(`Fetch error for flights ${from}-${to}:`, error);
    return null;
  }
}

// ─── REST OF FILE UNCHANGED ──────────────────────────────────────────────────

const exploreItems = [
  {
    title: 'Best Time to Visit Goa',
    tag: 'Travel Guide',
    query: 'Goa beach sunset travel',
    desc: 'Plan your perfect Goa getaway! Learn about the peak season vibes, pleasant monsoon escapes, and quiet off-season deals.',
    readTime: '5 min read',
    date: 'May 18, 2026'
  },
  {
    title: 'Top 10 Hill Stations Near Delhi',
    tag: 'Listicle',
    query: 'hill station mountains fog India',
    desc: 'Escape the city heat with these breathtaking Himalayan getaways, all located within a scenic drive or overnight train ride from Delhi.',
    readTime: '7 min read',
    date: 'May 15, 2026'
  },
  {
    title: 'Budget Trips Under ₹10K in India',
    tag: 'Budget Travel',
    query: 'backpacking India mountains budget',
    desc: 'Explore the country without breaking the bank. Discover affordable hostels, local food secrets, and budget transit tips.',
    readTime: '6 min read',
    date: 'May 12, 2026'
  },
  {
    title: 'Monsoon Destinations You Must See',
    tag: 'Seasonal',
    query: 'monsoon India waterfall nature green',
    desc: 'Witness India come alive in the rain. Discover pristine mist-covered valleys, roaring waterfalls, and serene lush green landscapes.',
    readTime: '4 min read',
    date: 'May 10, 2026'
  }
];

const irctcCategories = [
  { name: 'Rail Tour Packages', desc: 'Explore India via standard rail circuits', query: 'Indian Railways train scenic India' },
  { name: 'Bharat Gaurav Trains', desc: 'Theme-based luxury circuit trains', query: 'luxury train interior India palace on wheels' },
  { name: 'Pilgrimage Specials', desc: 'Divine journeys to major holy sites', query: 'Varanasi temple Aarti prayer' },
  { name: 'Air Tour Packages', desc: 'Domestic & International air travel', query: 'airplane flying sky clouds sunset' },
  { name: 'International Tours', desc: 'Global destinations at great prices', query: 'Dubai city skyline Burj Khalifa' },
  { name: 'Cruise Packages', desc: 'Short duration ocean & river cruises', query: 'luxury cruise ship ocean deck' },
  { name: 'Wellness & Spa', desc: 'Yoga & Ayurvedic retreats in nature', query: 'Yoga meditation Kerala nature' },
  { name: 'Hill Station Tours', desc: 'Escape to the pristine Himalayas', query: 'Himalayas mountains snow green' },
];

async function fetchPexels(query, size = 'medium', perPage = 1) {
  const r = await fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=${perPage}&orientation=landscape`, {
    headers: { Authorization: PEXELS_KEY }
  });
  const d = await r.json();
  if (d.photos && d.photos.length) {
    return d.photos[0].src[size] || d.photos[0].src.medium;
  }
  return 'https://images.pexels.com/photos/1285625/pexels-photo-1285625.jpeg?auto=compress&cs=tinysrgb&w=1600';
}

async function loadTrending() {
  const grid = document.getElementById('trending-grid');
  if (!grid) return;

  grid.innerHTML = '';

  for (const dest of destinations) {
    const slide = document.createElement('div');
    slide.className = 'swiper-slide relative h-80 md:h-[380px] rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 group cursor-pointer border border-gray-100/50';
    slide.innerHTML = `
      <!-- Background Image Container -->
<div class="group relative flex flex-col justify-between overflow-hidden rounded-xl bg-slate-50 border border-slate-200/80 w-full min-h-[380px] p-4 shadow-sm transition-all duration-300 hover:shadow-md hover:border-slate-300">
  
  <div class="img-container absolute inset-0 z-0 bg-slate-100 transition-transform duration-700 ease-out group-hover:scale-102">
    <div class="w-full h-full bg-slate-200/60 animate-pulse"></div>
  </div>
  
  <div class="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/40 z-10"></div>

  <div class="relative z-20 flex justify-between items-start w-full">
    <span class="primary-color text-[10px] font-bold tracking-widest uppercase text-white px-2.5 py-1 rounded shadow-sm">
      Trending
    </span>
    <div></div>
  </div>
  
  <div class="relative z-20 flex flex-col items-start text-left select-none w-full mt-auto bg-white p-4 rounded-lg border border-slate-100 shadow-sm">
    
    <p class="primary-text text-xs font-semibold tracking-wide flex items-center gap-1.5 mb-1 opacity-90">
      <i data-lucide="map-pin" class="w-3.5 h-3.5 shrink-0 opacity-80"></i>
      <span>${dest.desc}</span>
    </p>
    
    <h3 class="text-slate-800 font-bold text-lg md:text-xl leading-tight tracking-tight transition-colors duration-300 group-hover:text-slate-900">
      ${dest.name}
    </h3>
    
    <div class="w-full grid grid-rows-[0fr] opacity-0 transition-all duration-300 ease-in-out group-hover:grid-rows-[1fr] group-hover:opacity-100 group-hover:mt-2.5">
      <div class="overflow-hidden">
        <div class="primary-text inline-flex items-center gap-1.5 text-xs font-bold border-t border-slate-100 w-full pt-2.5 mt-1">
          <span>Explore Packages</span>
          <i data-lucide="arrow-right" class="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1"></i>
        </div>
      </div>
    </div>

  </div>
</div>`;
    grid.appendChild(slide);

    fetchPexels(dest.query, 'large2x').then(url => {
      const container = slide.querySelector('.img-container');
      container.innerHTML = `<img src="${url}" class="w-full h-full object-cover" alt="${dest.name}"/>`;
      if (window.lucide) { lucide.createIcons(); }
    });
  }

  if (window.lucide) { lucide.createIcons(); }

  new Swiper('.trending-swiper', {
    slidesPerView: 1.2,
    spaceBetween: 16,
    autoplay: {
      delay: 3500,
      disableOnInteraction: false,
    },
    breakpoints: {
      480: { slidesPerView: 1.8 },
      640: { slidesPerView: 2.2 },
      768: { slidesPerView: 3 },
      1024: { slidesPerView: 4 },
      1280: { slidesPerView: 5 }
    }
  });
}

async function loadPackages(query = 'Holiday Packages') {
  const grid = document.getElementById('packages-grid');
  if (!grid) return;

  grid.innerHTML = Array(3).fill(0).map(() => `
    <div class="bg-white rounded-2xl overflow-hidden border border-gray-100 animate-pulse">
      <div class="w-full h-52 bg-gray-200"></div>
      <div class="p-5 space-y-3">
        <div class="h-4 bg-gray-200 rounded w-1/4"></div>
        <div class="h-6 bg-gray-200 rounded w-3/4"></div>
        <div class="h-4 bg-gray-200 rounded w-1/2"></div>
      </div>
    </div>
  `).join('');

  const data = await fetchPackages(query);
  grid.innerHTML = '';

  if (!data || data.length === 0) {
    grid.innerHTML = `<div class="col-span-full py-12 text-center text-gray-500 font-medium">No packages found for this category.</div>`;
    return;
  }

  data.slice(0, 6).forEach((pkg, index) => {
    const card = document.createElement('div');
    card.className = 'swiper-slide h-auto md:!w-auto md:!mr-0 bg-white rounded-2xl overflow-hidden border border-gray-100 card-hover group';

    let rawPrice = pkg.rate_per_night?.lowest || '24,999';
    let numericPrice = 24999;
    if (typeof rawPrice === 'string') {
      numericPrice = parseFloat(rawPrice.replace(/[^0-9.]/g, '')) || 24999;
      if (rawPrice.includes('$')) numericPrice *= 83;
    }

    const totalPackagePrice = Math.round((numericPrice * 4) + 12000);
    const formattedPrice = `₹${totalPackagePrice.toLocaleString('en-IN')}`;

    const thumbnail = pkg.images?.[0]?.thumbnail || 'https://images.pexels.com/photos/1450353/pexels-photo-1450353.jpeg?auto=compress&cs=tinysrgb&w=600';
    const badges = ['Best Seller', 'Recommended', 'Limited Offer', 'New', 'Trending', 'Popular'];
    const badgeColors = ['bg-red-100 text-red-700', 'bg-green-100 text-green-700', 'bg-blue-100 text-blue-700', 'bg-purple-100 text-purple-700', 'bg-orange-100 text-orange-700', 'bg-pink-100 text-pink-700'];

    let locName = query.replace(/(Holiday|Packages|Beach|Backwaters|Hill Stations|Desert|Heritage|Tours)/gi, '').trim();
    if (!locName) locName = query.split(' ')[0];

    card.innerHTML = `<div class="relative h-56 overflow-hidden bg-slate-100">
  <img src="${thumbnail}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out" alt="${pkg.name}"/>
  
  <div class="absolute top-3 left-3 right-3 flex justify-between items-start z-10 w-full pr-6">
    <div class="${badgeColors[index % 6]} px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-wider shadow-sm">
      ${badges[index % 6]}
    </div>
    
    <button class="w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center text-slate-500 hover:text-red-500 hover:bg-white transition-all shadow-sm">
      <i data-lucide="heart" class="w-4 h-4"></i>
    </button>
  </div>

  <div class="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-slate-900/60 to-transparent"></div>
  
  <div class="absolute bottom-3 left-3 right-3 flex justify-between items-end z-20">
    <div class="flex items-center gap-1.5 text-white">
      <i data-lucide="map-pin" class="w-3.5 h-3.5 opacity-90 shrink-0"></i>
      <span class="text-xs font-semibold truncate max-w-[160px] drop-shadow-sm">${locName}</span>
    </div>
    <div class="flex items-center gap-1 bg-white/95 backdrop-blur-sm px-2 py-0.5 rounded shadow-sm text-slate-800">
      <i data-lucide="star" class="w-3 h-3 fill-amber-400 text-amber-400"></i>
      <span class="text-xs font-bold">${pkg.overall_rating ? Number(pkg.overall_rating).toFixed(1) : '4.8'}</span>
    </div>
  </div>
</div>

<div class="p-4 flex flex-col justify-between flex-grow bg-white">
  <div>
    <h3 class="font-bold text-slate-800 text-base md:text-lg leading-tight line-clamp-2 group-hover:text-[#2d2383] transition-colors duration-200">
      ${pkg.name.replace('Hotel', 'Package')}
    </h3>
    
    <div class="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-medium text-slate-500 mt-2">
      <span class="flex items-center gap-1"><i data-lucide="calendar" class="w-3.5 h-3.5 text-[#2d2383] opacity-80"></i> 5N/6D</span>
      <span class="text-slate-300">•</span>
      <span class="flex items-center gap-1"><i data-lucide="plane-takeoff" class="w-3.5 h-3.5 text-[#2d2383] opacity-80"></i> Flights</span>
      <span class="text-slate-300">•</span>
      <span class="flex items-center gap-1"><i data-lucide="utensils" class="w-3.5 h-3.5 text-[#2d2383] opacity-80"></i> Meals</span>
    </div>
  </div>

  <div>
    <div class="border-t border-slate-100 border-dashed my-3.5"></div>
    
    <div class="flex items-center justify-between">
      <div>
        <span class="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Starts from</span>
        <div class="flex items-baseline gap-0.5 mt-0.5">
          <span class="text-lg font-extrabold text-slate-900 leading-none">${formattedPrice}</span>
          <span class="text-[10px] text-slate-400 font-medium">/person</span>
        </div>
      </div>
      
      <a href="${pkg.link || 'https://www.google.com/travel/hotels'}" target="_blank" class="primary-color hover:bg-[#1e175a] text-white px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1 shadow-sm hover:shadow">
        <span>Book</span>
        <i data-lucide="chevron-right" class="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5"></i>
      </a>
    </div>
  </div>
</div>`;
    grid.appendChild(card);
  });
  if (window.lucide) { lucide.createIcons(); }

  if (window.packagesSwiper) { window.packagesSwiper.destroy(true, true); }
  window.packagesSwiper = new Swiper('.packages-mobile-swiper', {
    slidesPerView: 1.2,
    spaceBetween: 16,
    scrollbar: { el: '.packages-mobile-swiper .swiper-scrollbar', draggable: true },
    breakpoints: { 768: { enabled: false } }
  });
}

function setActiveFilter(btn) {
  document.querySelectorAll('.package-filter').forEach(b => {
    b.classList.remove('primary-color', 'text-white');
    b.classList.add('bg-white', 'text-gray-600', 'border', 'border-gray-200');
  });
  btn.classList.add('primary-color', 'text-white');
  btn.classList.remove('bg-white', 'text-gray-600', 'border', 'border-gray-200');
}

// Helper to initialize Swiper on a specific selector with its unique navigation buttons
function initFlightSwiper(swiperSelector, sectionSelector) {
  const section = document.querySelector(sectionSelector);
  if (!section || !window.Swiper) return;
  
  const navBtns = section.querySelectorAll('.flex.gap-2 button');

  new Swiper(swiperSelector, {
    slidesPerView: 1,
    spaceBetween: 16,
    scrollbar: {
      el: `${swiperSelector} .swiper-scrollbar`,
      draggable: true,
    },
    navigation: {
      prevEl: navBtns[0],
      nextEl: navBtns[1],
    },
    breakpoints: {
      576: { slidesPerView: 1, spaceBetween: 16 },
      768: { slidesPerView: 3, spaceBetween: 16 },
      1024: { slidesPerView: 3, spaceBetween: 16 }
    }
  });
}

// Master function to render flights for a given grid and route list
async function renderFlightGrid(gridId, routes, dateQuery, dateStr) {
  const grid = document.getElementById(gridId);
  if (!grid) return;

  // Render Skeletons
  grid.innerHTML = Array(4).fill(0).map(() => `
    <div class="swiper-slide bg-white border border-gray-100 rounded-2xl p-5 animate-pulse">
      <div class="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
      <div class="h-6 bg-gray-200 rounded w-3/4 mb-4"></div>
      <div class="h-10 bg-gray-200 rounded w-full"></div>
    </div>
  `).join('');

  const flightPromises = routes.map(r => fetchFlightDeals(r.from, r.to));
  const results = await Promise.all(flightPromises);

  grid.innerHTML = '';

  results.forEach((res, index) => {
    let flight = res ? res.data : null;
    const isIntl = gridId === 'intl-flight-deals-grid';

    // Robust Fallback: generate a random realistic flight if the API didn't return data
    if (!flight) {
      const airlines = isIntl 
        ? ['Emirates', 'Singapore Airlines', 'British Airways', 'Thai Airways', 'Malaysia Airlines', 'Japan Airlines', 'Air India', 'Air France']
        : ['IndiGo', 'Air India', 'Akasa Air', 'SpiceJet', 'Vistara', 'Air India Express'];
      const randomAirline = airlines[Math.floor(Math.random() * airlines.length)];
      
      const domesticBasePrices = [3299, 3899, 4299, 4599, 4999, 5499, 5999];
      const intlBasePrices = [12499, 9899, 14299, 28990, 16500, 15400, 11200, 7200];
      const prices = isIntl ? intlBasePrices : domesticBasePrices;
      const basePrice = prices[index % prices.length];
      const priceOffset = Math.floor(Math.random() * 2000) - 1000;
      const finalPrice = Math.max(isIntl ? 6000 : 3000, basePrice + priceOffset);
      
      const durations = isIntl ? [210, 240, 270, 300, 330, 360, 480] : [115, 120, 130, 140, 150, 160, 180];
      const randomDuration = durations[Math.floor(Math.random() * durations.length)];
      
      flight = {
        price: finalPrice,
        flights: [{
          airline: randomAirline,
          duration: randomDuration,
          flight_number: 100 + Math.floor(Math.random() * 800)
        }]
      };
    }

    const leg = flight.flights && flight.flights[0] ? flight.flights[0] : {};
    const currentAirline = leg.airline || routes[index].airline; 
    
    const price = flight.price ? `₹${flight.price.toLocaleString('en-IN')}` : (isIntl ? '₹12,499' : '₹4,299');
    const originalPrice = Math.round((flight.price || (isIntl ? 12499 : 4299)) * 1.35);
    const discount = Math.round(((originalPrice - (flight.price || (isIntl ? 12499 : 4299))) / originalPrice) * 100);

    const airlineCode = leg.airline_code || (currentAirline === 'IndiGo' ? '6E' : currentAirline?.substring(0, 2).toUpperCase() || 'AI');
    const flightNumber = leg.flight_number || (100 + index * 12);
    const flightNo = `${airlineCode} ${flightNumber}`;

    let bookingUrl = flight.link || `https://www.google.com/travel/flights?q=Flights%20to%20${routes[index].to}%20from%20${routes[index].from}%20on%20${dateQuery}`;
    
    if (!isIntl && (currentAirline === 'IndiGo' || airlineCode === '6E')) {
      bookingUrl = `https://www.goindigo.in/book/flight-select.html?fromIata=${routes[index].from}&toIata=${routes[index].to}&departureDate=${dateQuery}&adultCount=1&tripType=OW`;
    }

    const card = document.createElement('div');
    if (isIntl) {
      card.className = 'swiper-slide bg-white border border-gray-100 rounded-2xl card-hover flex flex-col justify-between overflow-hidden relative';
      card.style.height = 'auto';

      const destinationCity = routes[index].name.split('→')[1].trim();
      const placeholderImg = 'https://images.pexels.com/photos/1285625/pexels-photo-1285625.jpeg?auto=compress&cs=tinysrgb&w=600';
      
      const durationHours = leg.duration ? Math.floor(leg.duration / 60) : 2;
      const durationMinutes = leg.duration ? leg.duration % 60 : 15;

      card.innerHTML = `
        <div class="relative h-[160px] w-full overflow-hidden bg-slate-100">
          <img src="${placeholderImg}" id="intl-img-${index}" class="w-full h-full object-cover transition-transform duration-500 hover:scale-105" alt="${destinationCity}">
          <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent z-10"></div>
          <span class="absolute top-3 right-3 text-[10px] bg-white/95 text-[#2d2383] px-2.5 py-1 rounded-full font-bold border border-white/20 shadow-sm z-20">Best Fare</span>
          <div class="absolute bottom-3 left-3 z-20">
            <div class="text-[10px] text-white/80 font-bold uppercase tracking-widest flex items-center gap-1">
              <i data-lucide="map-pin" class="w-3 h-3 text-white"></i>
              <span>${destinationCity}</span>
            </div>
            <div class="font-bold text-white text-lg mt-0.5 leading-tight">${routes[index].name}</div>
          </div>
        </div>
        
        <div class="p-5 flex flex-col justify-between flex-grow">
          <div>
            <div class="flex justify-between items-center mb-4">
              <div class="text-[10px] text-gray-400 font-bold uppercase tracking-widest flex items-center gap-1">
                <i data-lucide="calendar" class="w-3.5 h-3.5 text-[#2d2383] opacity-80"></i>
                <span>DEPARTURE · ${dateStr}</span>
              </div>
              <span class="text-[10px] bg-green-50 text-green-700 px-2 py-0.5 rounded-full font-bold border border-green-100">${discount}% OFF</span>
            </div>
            
            <div class="flex items-center gap-3 mb-6">
              ${leg.airline_logo 
                ? `<img src="${leg.airline_logo}" class="w-6 h-6 object-contain" alt="${currentAirline}">` 
                : `<div class="w-6 h-6 rounded-full bg-slate-50 flex items-center justify-center border border-slate-100"><i data-lucide="plane" class="w-3.5 h-3.5 text-[#2d2383]"></i></div>`}
              <div class="text-xs text-gray-500 font-medium">
                <span class="text-gray-900 font-bold">${currentAirline}</span> · ${durationHours}h ${durationMinutes}m · Direct / 1-stop
              </div>
            </div>
          </div>
          <div class="flex items-end justify-between pt-4 border-t border-gray-50">
            <div>
              <div class="text-[10px] text-gray-400 line-through">₹${originalPrice.toLocaleString('en-IN')}</div>
              <div class="text-xl font-extrabold text-red-500">${price}</div>
              <div class="text-[10px] text-gray-400">per person</div>
            </div>
            <a href="${bookingUrl}" target="_blank" class="primary-color text-white text-xs px-5 py-2.5 rounded-xl font-bold shadow-sm hover:bg-[#1e175a] transition-all text-center">
              Book Now
            </a>
          </div>
        </div>`;
        
      fetchPexels(destinationCity, 'medium').then(url => {
        const imgEl = card.querySelector(`#intl-img-${index}`);
        if (imgEl) imgEl.src = url;
      });
    } else {
      card.className = 'swiper-slide bg-white border border-gray-100 rounded-2xl p-5 card-hover flex flex-col justify-between relative';
      card.style.height = 'auto';
      
      const durationHours = leg.duration ? Math.floor(leg.duration / 60) : 2;
      const durationMinutes = leg.duration ? leg.duration % 60 : 15;

      card.innerHTML = `
        <div>
          ${leg.airline_logo ? `<img src="${leg.airline_logo}" class="w-30 h-30 opacity-5 object-contain absolute top-4 right-4 pointer-events-none" alt="">` : ''}
          
          <div class="flex justify-between items-start mb-4 relative z-10">
            <div>
              <div class="text-[10px] text-gray-400 font-bold uppercase tracking-widest">${res.route || `${routes[index].from}-${routes[index].to}`} · ${dateStr}</div>
              <div class="font-bold text-gray-900 text-lg">${routes[index].name}</div>
              <div class="text-[10px] text-gray-400 font-bold mt-0.5">${flightNo}</div>
            </div>
            <span class="text-[10px] bg-green-50 text-green-700 px-2 py-1 rounded-full font-bold border border-green-100">${discount}% OFF</span>
          </div>
          <div class="flex items-center gap-3 mb-6 relative z-10">
            ${leg.airline_logo ? `<img src="${leg.airline_logo}" class="w-6 h-6 object-contain" alt="${currentAirline}">` : ''}
            <div class="text-xs text-gray-500 font-medium">
              <span class="text-gray-900 font-bold">${currentAirline}</span> · ${durationHours}h ${durationMinutes}m · Non-stop
            </div>
          </div>
        </div>
        <div class="flex items-end justify-between pt-4 border-t border-gray-50 relative z-10">
          <div>
            <div class="text-[10px] text-gray-400 line-through">₹${originalPrice.toLocaleString('en-IN')}</div>
            <div class="text-xl font-extrabold text-red-500">${price}</div>
            <div class="text-[10px] text-gray-400">per person</div>
          </div>
          <a href="${bookingUrl}" target="_blank" class="primary-color text-white text-xs px-5 py-2.5 rounded-xl font-bold shadow-sm hover:bg-[#1e175a] transition-all text-center">
            Book Now
          </a>
        </div>`;
    }
    grid.appendChild(card);
  });

  if (window.lucide) { lucide.createIcons(); }
}

// Orchestrator Function
async function loadFlights() {
  const dateStr = "20 Jun '26";
  const dateQuery = "2026-06-20";

  // 1. Domestic Routes Configuration
  const domesticRoutes = [
    { from: 'DEL', to: 'BOM', name: 'Delhi → Mumbai', airline: 'IndiGo' },
    { from: 'DEL', to: 'BLR', name: 'Delhi → Bengaluru', airline: 'Air India' },
    { from: 'DEL', to: 'GOI', name: 'Delhi → Goa', airline: 'Akasa Air' },
    { from: 'DEL', to: 'CCU', name: 'Delhi → Kolkata', airline: 'SpiceJet' },
    { from: 'DEL', to: 'MAA', name: 'Delhi → Chennai', airline: 'Air India Express' },
    { from: 'DEL', to: 'HYD', name: 'Delhi → Hyderabad', airline: 'Star Air' },
    { from: 'DEL', to: 'AMD', name: 'Delhi → Ahmedabad', airline: 'IndiGo' },
    { from: 'DEL', to: 'COK', name: 'Delhi → Kochi', airline: 'Air India' },
    { from: 'DEL', to: 'JAI', name: 'Delhi → Jaipur', airline: 'Alliance Air' },
    { from: 'DEL', to: 'IXC', name: 'Delhi → Chandigarh', airline: 'IndiGo' },
    { from: 'DEL', to: 'SXR', name: 'Delhi → Srinagar', airline: 'SpiceJet' },
    { from: 'DEL', to: 'IXB', name: 'Delhi → Bagdogra', airline: 'Akasa Air' }, 
    { from: 'DEL', to: 'VNS', name: 'Delhi → Varanasi', airline: 'Air India Express' },
    { from: 'DEL', to: 'TRV', name: 'Delhi → Thiruvananthapuram', airline: 'Air India' }
  ];

  // 2. NEW: International Routes Configuration
  const internationalRoutes = [
    { from: 'DEL', to: 'DXB', name: 'Delhi → Dubai', airline: 'Emirates' },
    { from: 'DEL', to: 'SIN', name: 'Delhi → Singapore', airline: 'Singapore Airlines' },
    { from: 'DEL', to: 'LHR', name: 'Delhi → London', airline: 'British Airways' },
    { from: 'DEL', to: 'BKK', name: 'Delhi → Bangkok', airline: 'Thai Airways' },
    { from: 'DEL', to: 'KUL', name: 'Delhi → Kuala Lumpur', airline: 'Malaysia Airlines' },
    { from: 'DEL', to: 'NRT', name: 'Delhi → Tokyo', airline: 'Japan Airlines' },
    { from: 'DEL', to: 'JFK', name: 'Delhi → New York', airline: 'Air India' },
    { from: 'DEL', to: 'CDG', name: 'Delhi → Paris', airline: 'Air France' }
  ];

  // Execute rendering operations in parallel
  await Promise.all([
    renderFlightGrid('flight-deals-grid', domesticRoutes, dateQuery, dateStr),
    renderFlightGrid('intl-flight-deals-grid', internationalRoutes, dateQuery, dateStr)
  ]);

  // Initialize Swipers safely with their explicit section parents
  initFlightSwiper('.flight-deals-swiper', '.domestic-section');
  initFlightSwiper('.intl-flight-deals-swiper', '.international-section');
}
function getAmenityIcon(amenity) {
  const a = amenity.toLowerCase();
  if (a.includes('wifi') || a.includes('wi-fi') || a.includes('internet')) return 'wifi';
  if (a.includes('breakfast') || a.includes('dining') || a.includes('restaurant') || a.includes('food') || a.includes('meal')) return 'utensils';
  if (a.includes('pool') || a.includes('swim')) return 'droplets';
  if (a.includes('air cond') || a.includes('ac') || a.includes('cool')) return 'wind';
  if (a.includes('park')) return 'car';
  if (a.includes('gym') || a.includes('fitness') || a.includes('workout') || a.includes('health')) return 'dumbbell';
  if (a.includes('spa') || a.includes('massage') || a.includes('sauna')) return 'sparkles';
  if (a.includes('bar') || a.includes('lounge') || a.includes('drink')) return 'glass-water';
  if (a.includes('room service') || a.includes('service')) return 'bell';
  if (a.includes('laundry') || a.includes('wash')) return 'shirt';
  if (a.includes('pet')) return 'paw-print';
  if (a.includes('kids') || a.includes('family') || a.includes('child')) return 'baby';
  return 'check';
}

async function loadHotels(location = 'India') {
  const grid = document.getElementById('hotels-grid');
  if (!grid) return;

  const title = grid.closest('section').querySelector('h2');
  if (title) title.textContent = `Top Hotels in ${location}`;

  grid.innerHTML = Array(6).fill(0).map(() => `
    <div class="bg-white rounded-2xl overflow-hidden border border-gray-100 animate-pulse">
      <div class="w-full h-52 bg-gray-200"></div>
      <div class="p-5 space-y-3">
        <div class="h-4 bg-gray-200 rounded w-1/4"></div>
        <div class="h-6 bg-gray-200 rounded w-3/4"></div>
        <div class="h-4 bg-gray-200 rounded w-1/2"></div>
        <div class="pt-3 border-t border-gray-100 flex justify-between">
          <div class="h-8 bg-gray-200 rounded w-1/3"></div>
          <div class="h-8 bg-gray-200 rounded w-1/4"></div>
        </div>
      </div>
    </div>
  `).join('');

  const hotelData = await fetchHotels(location);
  grid.innerHTML = '';

  if (!hotelData || hotelData.length === 0) {
    grid.innerHTML = `<div class="col-span-full py-12 text-center text-gray-500 font-medium">No hotels found for "${location}". Please try another city.</div>`;
    return;
  }

  hotelData.slice(0, 20).forEach(hotel => {
    const card = document.createElement('div');
    card.className = 'swiper-slide h-auto md:!w-auto md:!mr-0 bg-white rounded-2xl overflow-hidden border border-gray-100 card-hover group';

    let rawPrice = hotel.rate_per_night?.lowest || hotel.total_rate?.lowest || 'Contact for price';
    let formattedPrice = rawPrice;

    if (typeof rawPrice === 'string' && rawPrice.includes('$')) {
      const numericPrice = parseFloat(rawPrice.replace(/[^0-9.]/g, ''));
      if (!isNaN(numericPrice)) {
        formattedPrice = `₹${Math.round(numericPrice * 83).toLocaleString('en-IN')}`;
      }
    } else if (typeof rawPrice === 'string' && !rawPrice.includes('₹') && !isNaN(parseFloat(rawPrice.replace(/[^0-9.]/g, '')))) {
      const numericPrice = parseFloat(rawPrice.replace(/[^0-9.]/g, ''));
      formattedPrice = `₹${Math.round(numericPrice * 83).toLocaleString('en-IN')}`;
    }

    let thumbnail = hotel.images?.[0]?.thumbnail || 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=600';
    if (thumbnail.includes('googleusercontent.com')) {
      thumbnail = thumbnail.replace(/s\d+-w\d+-h\d+/g, 's1024-w1024-h768');
    }

    const amenities = (hotel.amenities || []).slice(0, 3).map(a => {
      const icon = getAmenityIcon(a);
      return `
        <span class="text-[10px] bg-gray-50 text-gray-600 px-2.5 py-0.5 rounded-full border border-gray-100 flex items-center gap-1.5 font-semibold">
          <i data-lucide="${icon}" class="w-3 h-3 text-[#2d2383]"></i>
          <span>${a}</span>
        </span>
      `;
    }).join('');

    card.innerHTML = `
      <div class="relative h-56 overflow-hidden">
        <img src="${thumbnail}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="${hotel.name}"/>
        <!-- Badges -->
        <div class="absolute top-4 left-4 flex gap-2 z-10">
          <div class="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider shadow-sm backdrop-blur-md">${hotel.deal_type || 'Premium Stay'}</div>
        </div>
        <!-- Save button -->
        <button class="absolute top-4 right-4 w-8 h-8 bg-white/80 backdrop-blur-md rounded-full flex items-center justify-center text-gray-500 hover:text-red-500 hover:bg-white transition-all z-10 shadow-sm">
          <i data-lucide="heart" class="w-4 h-4"></i>
        </button>
        <div class="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
        
        <!-- Location & Rating Overlay on Image -->
        <div class="absolute bottom-4 left-4 right-4 flex justify-between items-end z-20">
          <div class="flex items-center gap-1.5 text-white/95">
            <i data-lucide="map-pin" class="w-3.5 h-3.5 text-red-500 shrink-0"></i>
            <span class="text-xs font-black truncate max-w-[150px] drop-shadow-md">${location}</span>
          </div>
          <div class="flex items-center gap-1 bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-lg text-white border border-white/10">
            <i data-lucide="star" class="w-3.5 h-3.5 fill-yellow-400 text-yellow-400"></i>
            <span class="text-xs font-bold">${hotel.overall_rating ? Number(hotel.overall_rating).toFixed(1) : '4.5'}</span>
          </div>
        </div>
      </div>

      <div class="p-5 flex flex-col justify-between h-[calc(100%-14rem)]">
        <div>
          <h3 class="font-extrabold text-gray-900 text-lg leading-tight line-clamp-2 group-hover:text-[#2d2383] transition-colors">${hotel.name}</h3>
          
          <!-- Amenities -->
          <div class="flex flex-wrap gap-1.5 mt-3 mb-2 h-5 overflow-hidden">
            ${amenities}
          </div>
        </div>

        <div>
          <!-- Divider -->
          <div class="border-t border-gray-100 border-dashed my-4"></div>
          
          <!-- Price & Action -->
          <div class="flex items-center justify-between">
            <div>
              <span class="text-[10px] text-gray-400 font-bold uppercase tracking-wider block">Starts from</span>
              <div class="flex items-baseline gap-1 mt-0.5">
                <span class="text-xl font-black text-gray-900 leading-none">${formattedPrice}</span>
                <span class="text-[10px] text-gray-400">/night</span>
              </div>
            </div>
            <a href="${hotel.link || 'https://www.google.com/travel/hotels'}" target="_blank" class="primary-color hover:bg-[#1e175a] text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-1 hover:shadow-md">
              <span>Book</span>
              <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
            </a>
          </div>
        </div>
      </div>`;
    grid.appendChild(card);
  });
  if (window.lucide) { lucide.createIcons(); }

  if (window.hotelsSwiper) { window.hotelsSwiper.destroy(true, true); }
  window.hotelsSwiper = new Swiper('.hotels-mobile-swiper', {
    slidesPerView: 1.2,
    spaceBetween: 16,
    scrollbar: { el: '.hotels-mobile-swiper .swiper-scrollbar', draggable: true },
    breakpoints: { 768: { enabled: false } }
  });
}

let currentIRCTCTab = 'pilgrimage';
let currentIRCTCSort = 'name';

function setIRCTCTab(tab, btn) {
  currentIRCTCTab = tab;
  
  // Update active state of buttons
  document.querySelectorAll('.irctc-tab').forEach(b => {
    b.classList.remove('bg-[#2d2383]', 'text-white', 'border-[#2d2383]', 'shadow-sm');
    b.classList.add('bg-white', 'text-gray-600', 'border-gray-200');
  });
  if (btn) {
    btn.classList.add('bg-[#2d2383]', 'text-white', 'border-[#2d2383]', 'shadow-sm');
    btn.classList.remove('bg-white', 'text-gray-600', 'border-gray-200');
  }

  loadIRCTC();
}

function sortIRCTC(criteria, btn) {
  currentIRCTCSort = criteria;

  // Update active state of sort buttons
  document.querySelectorAll('.irctc-sort').forEach(b => {
    b.classList.remove('bg-white', 'text-[#2d2383]', 'shadow-sm');
    b.classList.add('text-gray-600');
  });
  if (btn) {
    btn.classList.add('bg-white', 'text-[#2d2383]', 'shadow-sm');
    btn.classList.remove('text-gray-600');
  }

  loadIRCTC();
}

async function loadIRCTC() {
  const grid = document.getElementById('irctc-grid');
  if (!grid) return;

  grid.innerHTML = '';

  // Filter by Tab
  let items = irctcSpecials.filter(item => item.tab === currentIRCTCTab);

  // Sort
  if (currentIRCTCSort === 'name') {
    items.sort((a, b) => a.title.localeCompare(b.title));
  } else if (currentIRCTCSort === 'price') {
    items.sort((a, b) => a.price - b.price);
  }

  items.forEach((item, index) => {
    const card = document.createElement('div');
    card.className = 'swiper-slide group relative rounded-3xl overflow-hidden cursor-pointer shadow-sm hover:shadow-xl transition-all duration-500 w-full sm:w-[350px] md:w-[380px] h-[530px] flex-shrink-0 bg-white border border-gray-100 flex flex-col justify-between';
    
    // Default placeholder image container
    card.innerHTML = `
      <div class="relative h-48 overflow-hidden bg-gray-100 flex-shrink-0">
        <div class="img-container absolute inset-0 z-0 bg-gray-200 animate-pulse"></div>
        <!-- Badges -->
        <div class="absolute top-4 left-4 flex flex-col gap-1.5 z-10">
          <span class="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider shadow-sm backdrop-blur-md">${item.tab === 'international' ? 'International Tour' : 'Bharat Gaurav Trains'}</span>
          <span class="bg-[#2d2383]/80 text-white px-2 py-0.5 rounded text-[9px] font-bold tracking-wider w-fit">${item.code}</span>
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent z-10"></div>
        
        <!-- Duration overlay -->
        <div class="absolute bottom-4 left-4 right-4 flex justify-between items-end z-20">
          <div class="flex items-center gap-1.5 text-white/95">
            <i data-lucide="calendar" class="w-3.5 h-3.5 text-amber-400 shrink-0"></i>
            <span class="text-xs font-black drop-shadow-md">${item.duration}</span>
          </div>
        </div>
      </div>

      <div class="p-5 flex flex-col justify-between h-[calc(100%-12rem)] flex-grow">
        <div>
          <h3 class="font-extrabold text-gray-900 text-base leading-snug line-clamp-2 group-hover:text-[#2d2383] transition-colors h-[44px]">${item.title}</h3>
          
          <!-- Departure Date Badge -->
          <div class="mt-3 flex items-center gap-1 bg-amber-500 text-white px-2.5 py-0.5 rounded-lg font-bold text-[10px] w-fit shadow-sm">
            <i data-lucide="calendar-range" class="w-3.5 h-3.5 shrink-0"></i>
            <span>Departs: ${item.departure}</span>
          </div>

          <!-- Origin and Destination info -->
          <div class="mt-5 space-y-2">
            <div class="flex items-start gap-1.5 text-xs text-gray-500">
              <i data-lucide="arrow-up-right" class="w-3.5 h-3.5 text-green-600 shrink-0 mt-0.5"></i>
              <span class="line-clamp-1"><strong class="text-gray-700">Origin:</strong> ${item.origin}</span>
            </div>
            <div class="flex items-start gap-1.5 text-xs text-gray-500">
              <i data-lucide="map-pin" class="w-3.5 h-3.5 text-red-500 shrink-0 mt-0.5"></i>
              <span class="line-clamp-2"><strong class="text-gray-700">Dest:</strong> ${item.destination}</span>
            </div>
          </div>

          <!-- Inclusions row -->
          <div class="flex items-center gap-2 mt-4">
            <span class="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Inclusions:</span>
            <div class="flex gap-1.5">
              ${item.inclusions.map(inc => `
                <div class="w-6 h-6 rounded-full bg-gray-50 border border-gray-100 flex items-center justify-center text-gray-600" title="${inc}">
                  <i data-lucide="${inc}" class="w-3.5 h-3.5 text-[#2d2383]"></i>
                </div>
              `).join('')}
            </div>
          </div>
        </div>

        <div>
          <!-- Divider -->
          <div class="border-t border-gray-100 border-dashed mt-[30px] mb-4"></div>
          
          <!-- Price & Action -->
          <div class="flex items-center justify-between">
            <div>
              <span class="text-[10px] text-gray-400 font-bold uppercase tracking-wider block">Starts from</span>
              <div class="flex items-baseline gap-1 mt-0.5">
                <span class="text-xl font-black text-gray-900 leading-none">₹${item.price.toLocaleString('en-IN')}</span>
                <span class="text-[10px] text-gray-400">/person</span>
              </div>
            </div>
            <a href="https://www.irctctourism.com" target="_blank" class="primary-color hover:bg-[#1e175a] text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-1 hover:shadow-md">
              <span>View Details</span>
              <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
            </a>
          </div>
        </div>
      </div>`;
    
    grid.appendChild(card);

    // Fetch dynamic image
    fetchPexels(item.query, 'large').then(url => {
      const container = card.querySelector('.img-container');
      if (container) {
        container.classList.remove('animate-pulse');
        container.innerHTML = `<img src="${url}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="${item.title}"/>`;
      }
      if (window.lucide) { lucide.createIcons(); }
    });
  });

  if (window.lucide) { lucide.createIcons(); }

  if (window.irctcSwiper) { window.irctcSwiper.destroy(true, true); }
  window.irctcSwiper = new Swiper('.irctc-swiper', {
    slidesPerView: 'auto',
    spaceBetween: 16,
    scrollbar: {
      el: '.irctc-swiper .swiper-scrollbar',
      draggable: true,
    },
    breakpoints: {
      576: { spaceBetween: 16 },
      768: { spaceBetween: 24 }
    }
  });
}

async function loadExplore() {
  const grid = document.getElementById('explore-grid');
  if (!grid) return;

  grid.innerHTML = '';

  for (const item of exploreItems) {
    const card = document.createElement('div');
    card.className = 'bg-white rounded-3xl overflow-hidden cursor-pointer shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 flex flex-col h-full group';
    card.innerHTML = `
      <div class="relative h-48 overflow-hidden bg-gray-100 flex-shrink-0">
        <div class="img-container absolute inset-0 z-0 bg-gray-200 animate-pulse"></div>
        <div class="absolute top-4 left-4 z-10">
          <span class="bg-[#2d2383] text-white text-[10px] font-extrabold uppercase tracking-wider px-3 py-1 rounded-full shadow-sm">
            ${item.tag}
          </span>
        </div>
      </div>
      <div class="p-6 flex flex-col justify-between flex-grow">
        <div>
          <div class="flex items-center gap-2 text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-2">
            <span>${item.date}</span>
            <span>•</span>
            <span>${item.readTime}</span>
          </div>
          <h3 class="font-extrabold text-gray-900 text-base leading-snug group-hover:text-[#2d2383] transition-colors line-clamp-2 mb-3">
            ${item.title}
          </h3>
          <p class="text-xs text-gray-500 leading-relaxed line-clamp-3 mb-6">
            ${item.desc}
          </p>
        </div>
        <div class="flex items-center text-xs font-bold text-[#2d2383] group-hover:text-[#1e175a] transition-colors gap-1.5 pt-4 border-t border-gray-50 mt-auto">
          <span>Read Full Article</span>
          <i data-lucide="arrow-right" class="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform"></i>
        </div>
      </div>
    `;
    grid.appendChild(card);

    fetchPexels(item.query, 'large').then(url => {
      const container = card.querySelector('.img-container');
      if (container) {
        container.classList.remove('animate-pulse');
        container.innerHTML = `<img src="${url}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="${item.title}"/>`;
      }
      if (window.lucide) { lucide.createIcons(); }
    });
  }
}

async function fetchPexelsVideo(query) {
  try {
    const r = await fetch(`https://api.pexels.com/videos/search?query=${encodeURIComponent(query)}&per_page=1&orientation=landscape`, {
      headers: { Authorization: PEXELS_KEY }
    });
    const d = await r.json();
    if (d.videos && d.videos.length > 0) {
      const video = d.videos[0];
      const files = video.video_files;
      // Filter for mp4 video files
      const mp4Files = files.filter(f => f.file_type === 'video/mp4');
      // Sort by resolution width descending to choose highest quality (HD)
      mp4Files.sort((a, b) => b.width - a.width);
      const bestFile = mp4Files[0] || files[0];
      return {
        videoUrl: bestFile ? bestFile.link : null,
        imageUrl: video.image || null
      };
    }
  } catch (error) {
    console.error('Error fetching pexels video:', error);
  }
  return null;
}

function setCategory(cat, btn) {
  document.querySelectorAll('.category-tab').forEach(t => {
    t.classList.remove('active');
  });
  if (btn) btn.classList.add('active');

  document.querySelectorAll('[id^="form-"]').forEach(f => {
    f.classList.add('hidden');
    f.classList.remove('fade-in');
  });
  const form = document.getElementById('form-' + cat);
  if (form) {
    form.classList.remove('hidden');
    setTimeout(() => form.classList.add('fade-in'), 10);
  }

  const img = document.getElementById('hero-img');
  const video = document.getElementById('hero-video');

  const queries = {
    flights: 'airplane flight sky clouds',
    hotels: 'luxury hotel resort pool lobby',
    homestays: 'tropical villa pool garden',
    holidays: 'maldives beach paradise tropical',
    trains: 'scenic train ride landscape railway',
    buses: 'travel coach bus highway road',
    cabs: 'car driving city highway',
    tours: 'india tourism taj mahal monument',
    cruise: 'cruise ship ocean travel',
    forex: 'money paper currency exchange',
    insurance: 'family travel safety vacation',
    visa: 'passport stamp travel document'
  };

  const query = queries[cat] || cat;

  if (img) img.style.opacity = '0';
  if (video) video.style.opacity = '0';

  // Load video and matching poster image
  fetchPexelsVideo(query).then(media => {
    if (media && media.videoUrl) {
      // 1. Instantly display the matched video frame/thumbnail
      if (img && media.imageUrl) {
        img.src = media.imageUrl;
        img.style.opacity = '1';
      }

      // 2. Play the video
      if (video) {
        video.src = media.videoUrl;
        video.load();

        const onPlaying = () => {
          video.style.opacity = '1';
          if (img) img.style.opacity = '0';
          video.removeEventListener('playing', onPlaying);
        };
        video.addEventListener('playing', onPlaying);

        video.play().catch(err => {
          console.warn('Video playback deferred or failed:', err);
          if (img) img.style.opacity = '1';
        });
      }
    } else {
      // Fallback to standard Pexels image search
      fetchPexels(query, 'large2x').then(url => {
        if (img) {
          img.src = url;
          img.style.opacity = '1';
        }
      });
    }
  });
}


function setSpecialFare(element) {
  document.querySelectorAll('.special-fare-tag').forEach(tag => tag.classList.remove('active'));
  element.classList.add('active');
}

function toggleTripType(type) {
  const returnField = document.getElementById('return-date-field');
  const returnText = returnField.querySelector('.font-bold');

  if (type === 'one-way') {
    returnField.classList.add('opacity-40', 'pointer-events-none');
    returnText.classList.replace('text-[#2d2383]', 'text-gray-400');
    returnText.textContent = 'Select Date';
  } else {
    returnField.classList.remove('opacity-40', 'pointer-events-none');
    returnText.classList.replace('text-gray-400', 'text-[#2d2383]');
    returnText.textContent = '18 May \'26';
  }
}

function swapCities() {
  const fromEl = document.querySelector('#form-flights .grid .border:nth-child(1) .font-bold');
  const toEl = document.querySelector('#form-flights .grid .border:nth-child(3) .font-bold');
  if (fromEl && toEl) {
    const tmp = fromEl.textContent;
    fromEl.textContent = toEl.textContent;
    toEl.textContent = tmp;
  }
}

function loadBannerSwiper() {
  new Swiper('.banner-swiper', {
    slidesPerView: 1,
    loop: true,
    spaceBetween: 20,
    autoplay: {
      delay: 3500,
      disableOnInteraction: false,
    },
    pagination: {
      el: '.banner-swiper .swiper-pagination',
      type: 'progressbar',
    },
    navigation: {
      nextEl: '.banner-swiper .swiper-button-next',
      prevEl: '.banner-swiper .swiper-button-prev',
    },
    breakpoints: {
      1200: { slidesPerView: 4, spaceBetween: 24 },
      0: { slidesPerView: 1, spaceBetween: 0 }
    }
  });
}

function toggleFAQ(button) {
  const content = button.nextElementSibling;
  const icon = button.querySelector('i');
  if (!content || !icon) return;
  document.querySelectorAll('#faq-accordion > div > div:last-child').forEach(div => {
    if (div !== content && !div.classList.contains('hidden')) {
      div.classList.add('hidden');
      div.previousElementSibling.querySelector('i').style.transform = 'rotate(0deg)';
    }
  });
  const isHidden = content.classList.contains('hidden');
  content.classList.toggle('hidden');
  icon.style.transform = isHidden ? 'rotate(180deg)' : 'rotate(0deg)';
}

const offersData = [
  { alt: "HDFC Offer", src: "assets/img/offers/c12b54020c3b56cb3e4e463ea648e072-owadr.webp" },
  { alt: "ICICI Offer", src: "assets/img/offers/880c2ea6ea53008c7edcc838f6a082a5-vfoli.webp" },
  { alt: "SBI Offer", src: "assets/img/offers/4853ad01d251f4075cb8741d90f1af09-vuhjt.webp" },
  { alt: "Jewar Airport", src: "assets/img/offers/cc80560a72eb476a7d75c53c8d4f7914-lpozf.webp" },
  { alt: "Kotak Offer", src: "assets/img/offers/fa78ea6fb8feff0bb6f0fbdceb42d753-xegzt.webp" }
];

function loadOffers() {
  const container = document.getElementById('offers-scroll');
  if (!container) return;
  // Duplicate the array to scroll twice
  const duplicated = [...offersData, ...offersData];
  container.innerHTML = duplicated.map(offer => `
    <div class="shrink-0 overflow-hidden rounded-2xl h-auto transition-transform hover:-translate-y-1 duration-300 cursor-pointer" style="scroll-snap-align:start">
      <img alt="${offer.alt}" loading="lazy" width="295" height="180" class="object-cover h-[180px] w-[295px]" src="${offer.src}">
    </div>
  `).join('');
}

// ─── INIT ────────────────────────────────────────────────────────────────────
loadTrending();
loadPackages('India Holiday Packages');
loadFlights();
loadHotels();
loadIRCTC();
loadExplore();
loadBannerSwiper();
loadOffers();

// Initialize the active category tab media (video/image)
setTimeout(() => {
  setCategory('flights', document.querySelector('.category-tab.active'));
}, 100);