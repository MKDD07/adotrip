
const PEXELS_API_KEY = 'y6WP5reQNH7abdL2uzdLTyV8pq0kMmF3CHf7ZNkiHo98DXIvORUOBSfi';
const PEXELS_API = 'https://api.pexels.com/v1/search';

let allDestinations = [];
let filteredDestinations = [];
let currentPage = 1;
const itemsPerPage = 12;
const imageCache = {};

// Destination data
const destinationsData = [
    {
        id: 1,
        name: 'Assi Ghat',
        state: 'Uttar Pradesh',
        city: 'Varanasi',
        category: 'Spiritual',
        description: 'As the southernmost embankment in the holy city of Varanasi, Assi Ghat serves as a profound spiritual gateway where the Assi River meets the Ganges. It is famously known for the Subah-e-Banaras, a mesmerizing morning ritual involving Vedic chants, traditional music, and a grand fire ceremony that welcomes the first rays of the sun, drawing pilgrims and travelers into a timeless dance of faith and ancient tradition.',
        searchQuery: 'Varanasi Assi Ghat spiritual morning',
        rating: 4.8,
        packageQty: 12,
        season: 'Autumn'
    },
    {
        id: 2,
        name: 'Juhu Beach',
        state: 'Maharashtra',
        city: 'Mumbai',
        category: 'Beach',
        description: 'Situated along the shores of the Arabian Sea, Juhu Beach is the beating heart of Mumbai’s coastline, where golden sands stretch for miles against a backdrop of luxury hotels and celebrity residences. It is a vibrant cultural melting pot where the aroma of spicy Pav Bhaji and Bhel Puri fills the air, and locals gather to witness spectacular crimson sunsets that paint the city’s skyline in shades of fire and gold.',
        searchQuery: 'Mumbai Juhu beach sunset food',
        rating: 4.5,
        packageQty: 8,
        season: 'Winter'
    },
    {
        id: 3,
        name: 'Digha',
        state: 'West Bengal',
        city: 'Digha',
        category: 'Beach',
        description: 'Digha is West Bengal’s most popular seaside resort, offering a serene escape characterized by casuarina plantations that line the coast. The destination features both Old Digha, with its nostalgic charm and stone-walled embankments, and New Digha, which boasts wider sandy beaches and gentle waves, making it an ideal sanctuary for those seeking a quiet weekend of seafood, sea breezes, and rhythmic tides.',
        searchQuery: 'Digha beach West Bengal weekend trip',
        rating: 4.3,
        packageQty: 5,
        season: 'Winter'
    },
    {
        id: 4,
        name: 'Murudeshwara',
        state: 'Karnataka',
        city: 'Uttara Kannada',
        category: 'Beach',
        description: 'Dominated by the world’s second-tallest statue of Lord Shiva, Murudeshwara is a breathtaking fusion of architectural grandeur and coastal beauty. The towering Rajagopura overlooks the turquoise waters of the Arabian Sea, while the surrounding beaches offer a tranquil retreat where the sound of temple bells harmonizes with the crashing waves, creating an atmosphere of divine peace and natural splendor.',
        searchQuery: 'Murudeshwara Shiva statue Karnataka coast',
        rating: 4.7,
        packageQty: 15,
        season: 'Winter'
    },
    {
        id: 5,
        name: 'Nandi Hills',
        state: 'Karnataka',
        city: 'Bangalore',
        category: 'Mountain',
        description: 'Rising above the clouds just a short drive from the bustle of Bangalore, Nandi Hills is an ancient hill fortress that offers panoramic vistas of the Deccan Plateau. It is most famous for its sunrise views, where a thick blanket of mist covers the valley below like a white ocean, and its historic trails lead explorers through Tipu Sultan’s summer retreat and ancient temples carved into the rugged stone.',
        searchQuery: 'Nandi Hills Bangalore sunrise trekking',
        rating: 4.6,
        packageQty: 20,
        season: 'Autumn'
    },
    {
        id: 6,
        name: 'Bhuntar',
        state: 'Himachal Pradesh',
        city: 'Kullu',
        category: 'Mountain',
        description: 'Nestled at the confluence of the Beas and Parvati rivers, Bhuntar serves as the emerald gateway to the mystical valleys of Kullu and Kasol. Surrounded by dense pine forests and snow-capped Himalayan peaks, this mountain town is a hub for adventure seekers looking to explore the hidden hamlets of the North, offering a raw and authentic experience of high-altitude life and pristine mountain air.',
        searchQuery: 'Bhuntar Kullu valley Himalaya trekking',
        rating: 4.9,
        packageQty: 18,
        season: 'Summer'
    },
    {
        id: 7,
        name: 'Lataguri',
        state: 'West Bengal',
        city: 'Alipurduar',
        category: 'Wildlife',
        description: 'Located on the fringes of Gorumara National Park, Lataguri is a lush paradise for nature enthusiasts and wildlife photographers. This dense forest region is home to the majestic Indian rhinoceros, Asiatic elephants, and a kaleidoscope of tropical birds. A jungle safari through its emerald canopy reveals a world where the wild reigns supreme, offering a thrilling glimpse into the untamed heart of the Dooars region.',
        searchQuery: 'Lataguri jungle safari Gorumara wildlife',
        rating: 4.7,
        packageQty: 10,
        season: 'Autumn'
    },
    {
        id: 8,
        name: 'Sahastradhara',
        state: 'Uttarakhand',
        city: 'Dehradun',
        category: 'Mountain',
        description: 'Meaning "Thousand-fold Spring," Sahastradhara is a natural wonder where water drips from limestone stalactites into cooling pools. The water is rich in sulfur and known for its therapeutic properties, attracting visitors who come to bathe in its healing cascades. Set against a backdrop of verdant hills and stepped rock formations, it is a mystical sanctuary where the earth literally weeps beauty.',
        searchQuery: 'Sahastradhara Dehradun sulfur springs waterfall',
        rating: 4.4,
        packageQty: 6,
        season: 'Summer'
    },
    {
        id: 9,
        name: 'Manali',
        state: 'Himachal Pradesh',
        city: 'Manali',
        category: 'Mountain',
        description: 'Manali is a high-altitude Himalayan resort town that acts as a magnet for backpackers and honeymooners alike. From the vibrant cafes of Old Manali to the snow-covered slopes of Rohtang Pass, it offers a diverse range of experiences including paragliding, skiing, and trekking. The town is wrapped in cedar forests and apple orchards, with the Beas River rushing through its heart, providing a constant soundtrack to its alpine charm.',
        searchQuery: 'Manali snow mountains adventure sports',
        rating: 4.8,
        packageQty: 25,
        season: 'Summer'
    },
    {
        id: 10,
        name: 'Darjeeling',
        state: 'West Bengal',
        city: 'Darjeeling',
        category: 'Mountain',
        description: 'Perched in the foothills of the Himalayas, Darjeeling is world-renowned for its sprawling tea estates and the iconic "Toy Train" which is a UNESCO World Heritage site. On a clear day, the Kanchenjunga peak towers over the town in a majestic display of ice and light. The colonial architecture, vibrant Tibetan monasteries, and the aroma of freshly brewed tea make it a quintessential mountain retreat.',
        searchQuery: 'Darjeeling tea gardens Kanchenjunga view',
        rating: 4.9,
        packageQty: 14,
        season: 'Autumn'
    },
    {
        id: 11,
        name: 'Rishikesh',
        state: 'Uttarakhand',
        city: 'Rishikesh',
        category: 'Spiritual',
        description: 'Known as the Yoga Capital of the World, Rishikesh sits where the emerald Ganges flows down from the Himalayas into the plains. It is a place of profound spiritual energy, filled with ashrams, temples, and the sound of evening chants at Triveni Ghat. Beyond its spiritual core, it is a global destination for white-water rafting and bungee jumping, offering a unique balance of inner peace and outer thrill.',
        searchQuery: 'Rishikesh yoga ashram river rafting',
        rating: 4.7,
        packageQty: 22,
        season: 'Winter'
    },
    {
        id: 12,
        name: 'Goa',
        state: 'Goa',
        city: 'Panaji',
        category: 'Beach',
        description: 'Goa is a coastal gem that seamlessly blends the laid-back "Susegad" lifestyle with a rich Indo-Portuguese heritage. From the white sands of Palolem to the vibrant party scene of Anjuna, the state offers a beach for every mood. Its landscape is dotted with centuries-old churches, colorful spice plantations, and hidden backwaters, making it a tropical paradise that transcends its reputation as just a party destination.',
        searchQuery: 'Goa beaches heritage churches nightlife',
        rating: 4.6,
        packageQty: 30,
        season: 'Winter'
    },
    {
        id: 13,
        name: 'Kaziranga',
        state: 'Assam',
        city: 'Kanchanjuri',
        category: 'Wildlife',
        description: 'A sanctuary of immense biological diversity, Kaziranga National Park is the last stronghold of the Great Indian One-Horned Rhinoceros. The landscape is a sea of tall elephant grass and marshy lagoons, bisected by the mighty Brahmaputra River. Visitors on elephant-back or jeep safaris can witness a prehistoric world where rhinos, tigers, and wild water buffalo roam freely in a protected wilderness.',
        searchQuery: 'Kaziranga rhinoceros safari Assam wildlife',
        rating: 4.8,
        packageQty: 11,
        season: 'Winter'
    },
    {
        id: 14,
        name: 'Leh',
        state: 'Ladakh',
        city: 'Leh',
        category: 'Mountain',
        description: 'Leh is a high-altitude desert city located at an elevation of 3,500 meters, characterized by its stark, moon-like landscapes and ancient Buddhist monasteries perched on jagged cliffs. The region is famous for its crystal-clear blue lakes like Pangong Tso and high mountain passes like Khardung La. It is a land of extreme beauty and deep silence, where prayer flags flutter in the thin, cold mountain air.',
        searchQuery: 'Leh Ladakh monasteries Pangong lake',
        rating: 4.9,
        packageQty: 16,
        season: 'Summer'
    },
    {
        id: 15,
        name: 'Puri',
        state: 'Odisha',
        city: 'Puri',
        category: 'Spiritual',
        description: 'Puri is one of the four sacred Char Dham pilgrimage sites, home to the majestic 12th-century Jagannath Temple. The city is a vibrant center of Odia culture, famous for its annual Rath Yatra festival where massive chariots are pulled through the streets. Beyond its temples, the golden sands of Puri Beach offer a spiritual and recreational refuge on the Bay of Bengal, famous for its unique sand art.',
        searchQuery: 'Puri Jagannath temple beach festival',
        rating: 4.5,
        packageQty: 19,
        season: 'Winter'
    },
    {
        id: 16,
        name: 'Udaipur',
        state: 'Rajasthan',
        city: 'Udaipur',
        category: 'Heritage',
        description: 'Often referred to as the "Venice of the East," Udaipur is a city of ethereal beauty built around the shimmering waters of Lake Pichola. Its skyline is dominated by the massive City Palace, a marvel of marble and granite. With its narrow winding streets, romantic sunset boat rides, and ornate havelis, Udaipur captures the regal essence of Rajasthan’s royal past in a breathtakingly picturesque setting.',
        searchQuery: 'Udaipur lake palace Rajasthan heritage',
        rating: 4.7,
        packageQty: 21,
        season: 'Winter'
    },
    {
        id: 17,
        name: 'Jim Corbett',
        state: 'Uttarakhand',
        city: 'Ramnagar',
        category: 'Wildlife',
        description: 'As Indias oldest national park, Jim Corbett is a legendary destination for tiger conservation and eco-tourism. Situated in the foothills of the Himalayas, the park features diverse terrain ranging from riverine belts and grasslands to large lakes. It offers a raw encounter with nature, where the roar of the Royal Bengal Tiger echoes through the Sal forests and the Ramganga River provides a lifeline for hundreds of species.',
        searchQuery: 'Jim Corbett tiger safari Uttarakhand forest',
        rating: 4.6,
        packageQty: 13,
        season: 'Winter'
    },
    {
        id: 18,
        name: 'Alleppey',
        state: 'Kerala',
        city: 'Alappuzha',
        category: 'Beach',
        description: 'Alleppey, or Alappuzha, is the hub of Kerala’s legendary backwaters, a network of tranquil canals, lagoons, and lakes. The quintessential experience here involves drifting on a traditional wooden houseboat through palm-fringed waters, watching the rural life of "God’s Own Country" unfold along the banks. It is a slow-paced paradise where the water reflects the deep green of the surrounding coconut groves.',
        searchQuery: 'Alleppey backwaters houseboat Kerala tourism',
        rating: 4.8,
        packageQty: 24,
        season: 'Autumn'
    },
    {
        id: 19,
        name: 'Tawang',
        state: 'Arunachal Pradesh',
        city: 'Tawang',
        category: 'Mountain',
        description: 'Hidden in the far northeastern corner of India, Tawang is a mystical land of high mountain passes and glacial lakes. It is home to the Tawang Monastery, the largest in India, which sits like a crown atop a hill at 10,000 feet. The region is a spiritual and visual masterpiece, offering glimpses of the Sela Pass and frozen waterfalls, making it one of the most remote and enchanting mountain frontiers on earth.',
        searchQuery: 'Tawang monastery Arunachal mountains Sela pass',
        rating: 4.9,
        packageQty: 7,
        season: 'Summer'
    },
    {
        id: 20,
        name: 'Hampi',
        state: 'Karnataka',
        city: 'Hospet',
        category: 'Heritage',
        description: 'Hampi is an open-air museum of ruins scattered across a surreal landscape of giant boulders and verdant paddy fields. Once the capital of the prosperous Vijayanagara Empire, its remnants include magnificent temples, royal pavilions, and aquatic structures that showcase unparalleled Dravidian craftsmanship. Walking through Hampi is like stepping back in time to an era of architectural wonder and imperial glory.',
        searchQuery: 'Hampi ruins UNESCO heritage site Karnataka',
        rating: 4.8,
        packageQty: 17,
        season: 'Winter'
    }
];
const similarDestinations = [
    { id: 101, name: 'Shimla', state: 'Himachal Pradesh', category: 'Mountain', description: 'Often called the Queen of Hills, Shimla is a picturesque colonial-era hill station known for its Victorian architecture, the bustling Mall Road, and panoramic views of the snow-capped Shivalik ranges.', searchQuery: 'Shimla mountains mall road', rating: 4.5, packageQty: 10, season: 'Summer' },
    { id: 102, name: 'Ooty', state: 'Tamil Nadu', category: 'Mountain', description: 'Nestled in the Nilgiri Hills, Ooty is famous for its sprawling botanical gardens, serene lakes, and the charming Nilgiri Mountain Railway that winds through emerald-green tea plantations.', searchQuery: 'Ooty gardens tea estates', rating: 4.7, packageQty: 12, season: 'Summer' },
    { id: 103, name: 'Munnar', state: 'Kerala', category: 'Mountain', description: 'A lush haven in the Western Ghats, Munnar is defined by rolling hills carpeted in tea bushes, misty valleys, and the Eravikulam National Park, home to the endangered Nilgiri Tahr.', searchQuery: 'Munnar tea gardens Kerala', rating: 4.8, packageQty: 15, season: 'Autumn' },
    { id: 104, name: 'Coorg', state: 'Karnataka', category: 'Mountain', description: 'Known as the Scotland of India, Coorg is a misty landscape of coffee plantations, spice gardens, and cascading waterfalls like Abbey Falls, perfect for nature lovers and trekkers.', searchQuery: 'Coorg coffee plantation waterfalls', rating: 4.6, packageQty: 8, season: 'Autumn' },
    { id: 105, name: 'Gulmarg', state: 'Jammu & Kashmir', category: 'Mountain', description: 'A premier skiing destination in the heart of Kashmir, Gulmarg offers the world highest gondola ride and vast meadows that transform into a white wonderland during the winter months.', searchQuery: 'Gulmarg skiing Kashmir snow', rating: 4.9, packageQty: 14, season: 'Winter' },
    { id: 106, name: 'Kodaikanal', state: 'Tamil Nadu', category: 'Mountain', description: 'Situated in the Palani Hills, Kodaikanal is centered around a star-shaped man-made lake and is surrounded by dense forests, granite cliffs, and grassy hills that stay cool year-round.', searchQuery: 'Kodaikanal lake hills Tamil Nadu', rating: 4.5, packageQty: 11, season: 'Summer' },
    { id: 107, name: 'Mahabaleshwar', state: 'Maharashtra', category: 'Mountain', description: 'A popular hill station in the Sahyadri range, famous for its strawberry farms, ancient temples, and numerous viewpoints overlooking the rugged valleys of the Western Ghats.', searchQuery: 'Mahabaleshwar strawberries viewpoints', rating: 4.4, packageQty: 13, season: 'Winter' },
    { id: 108, name: 'Cherrapunji', state: 'Meghalaya', category: 'Mountain', description: 'One of the wettest places on earth, Cherrapunji is a land of living root bridges, plunging waterfalls like Nohkalikai, and mysterious limestone caves hidden in the clouds.', searchQuery: 'Cherrapunji root bridges waterfalls', rating: 4.7, packageQty: 9, season: 'Monsoon' },
    { id: 109, name: 'Dalhousie', state: 'Himachal Pradesh', category: 'Mountain', description: 'Spanning five hills and retaining its colonial charm, Dalhousie offers pine-clad valleys and views of the Dhauladhar range that feel like a scene out of a vintage postcard.', searchQuery: 'Dalhousie Himachal pine forests', rating: 4.6, packageQty: 10, season: 'Summer' },
    { id: 110, name: 'Pondicherry', state: 'Puducherry', category: 'Beach', description: 'A unique blend of French colonial heritage and Indian culture, Pondicherry features mustard-yellow villas, quiet cobblestone streets, and serene beaches like Paradise Beach.', searchQuery: 'Pondicherry french quarter beach', rating: 4.6, packageQty: 18, season: 'Winter' },
    { id: 111, name: 'Gokarna', state: 'Karnataka', category: 'Beach', description: 'A laid-back alternative to Goa, Gokarna is famous for its Om Beach, rustic beach shacks, and a spiritual atmosphere centered around the ancient Mahabaleshwar Temple.', searchQuery: 'Gokarna beaches Om beach trek', rating: 4.7, packageQty: 7, season: 'Winter' },
    { id: 112, name: 'Kovalam', state: 'Kerala', category: 'Beach', description: 'Famous for its iconic red-and-white striped lighthouse, Kovalam is a crescent-shaped coastline in Kerala known for its shallow waters and ayurvedic massage centers.', searchQuery: 'Kovalam lighthouse beach Kerala', rating: 4.5, packageQty: 20, season: 'Winter' },
    { id: 113, name: 'Varkala', state: 'Kerala', category: 'Beach', description: 'Varkala is unique for its dramatic red laterite cliffs that overlook the Arabian Sea, offering a bohemian vibe with cliff-top cafes and natural mineral springs.', searchQuery: 'Varkala cliff beach Kerala', rating: 4.8, packageQty: 12, season: 'Winter' },
    { id: 114, name: 'Andaman Islands', state: 'Andaman & Nicobar', category: 'Beach', description: 'A tropical paradise with turquoise waters and white sand beaches like Radhanagar Beach, offering world-class scuba diving and snorkeling in vibrant coral reefs.', searchQuery: 'Andaman scuba diving Radhanagar beach', rating: 4.9, packageQty: 25, season: 'Winter' },
    { id: 115, name: 'Haridwar', state: 'Uttarakhand', category: 'Spiritual', description: 'One of the seven holiest places in Hinduism, where the Ganges enters the plains. The evening Ganga Aarti at Har Ki Pauri is a spectacular display of light and devotion.', searchQuery: 'Haridwar Ganga Aarti spiritual', rating: 4.8, packageQty: 22, season: 'Autumn' },
    { id: 116, name: 'Amritsar', state: 'Punjab', category: 'Spiritual', description: 'Home to the Golden Temple, the holiest shrine of Sikhism, Amritsar is a city of immense hospitality, deep history, and some of the best street food in North India.', searchQuery: 'Amritsar Golden Temple history', rating: 4.9, packageQty: 15, season: 'Winter' },
    { id: 117, name: 'Tirupati', state: 'Andhra Pradesh', category: 'Spiritual', description: 'Perched on the Tirumala Hills, this is one of the most visited pilgrimage sites in the world, famous for the ancient Venkateswara Temple and its grand traditions.', searchQuery: 'Tirupati Balaji temple pilgrimage', rating: 4.7, packageQty: 30, season: 'Winter' },
    { id: 118, name: 'Ranthambore', state: 'Rajasthan', category: 'Wildlife', description: 'A former royal hunting ground, Ranthambore is now a premier tiger reserve where history meets wildlife amidst the ruins of a 10th-century hilltop fort.', searchQuery: 'Ranthambore tiger safari Rajasthan', rating: 4.6, packageQty: 11, season: 'Winter' },
    { id: 119, name: 'Bandhavgarh', state: 'Madhya Pradesh', category: 'Wildlife', description: 'Boasting one of the highest densities of Royal Bengal Tigers in India, this park in Madhya Pradesh is a hilly terrain of mixed forests and ancient caves.', searchQuery: 'Bandhavgarh tiger safari MP', rating: 4.7, packageQty: 9, season: 'Winter' },
    { id: 120, name: 'Khajuraho', state: 'Madhya Pradesh', category: 'Heritage', description: 'A UNESCO World Heritage site famous for its stunning group of Hindu and Jain temples adorned with intricate, expressive, and world-renowned erotic sculptures.', searchQuery: 'Khajuraho temples heritage MP', rating: 4.8, packageQty: 14, season: 'Autumn' }

];

const mostLovedDestinations = [
    { id: 201, name: 'Taj Mahal', state: 'Uttar Pradesh', category: 'Heritage', description: 'A UNESCO World Heritage site and a symbol of eternal love, this white ivory-marble mausoleum is widely considered the jewel of Muslim art in India.', searchQuery: 'Taj Mahal Agra', loves: 15420, season: 'Winter' },
    { id: 202, name: 'Hawa Mahal', state: 'Rajasthan', category: 'Heritage', description: 'The Palace of Winds features a unique five-story exterior with 953 small windows designed to allow royal ladies to observe street festivals unseen.', searchQuery: 'Hawa Mahal Jaipur', loves: 12890, season: 'Winter' },
    { id: 203, name: 'Gateway of India', state: 'Maharashtra', category: 'Heritage', description: 'An arch-monument built during the 20th century in Bombay to commemorate the landing of King-Emperor George V and Queen-Mary at Apollo Bunder.', searchQuery: 'Gateway of India Mumbai', loves: 14560, season: 'Winter' },
    { id: 204, name: 'Kerala Backwaters', state: 'Kerala', category: 'Nature', description: 'A chain of brackish lagoons and lakes lying parallel to the Arabian Sea coast, famous for its peaceful houseboat cruises through palm-fringed waters.', searchQuery: 'Kerala backwaters houseboat', loves: 13240, season: 'Autumn' },
    { id: 205, name: 'Amer Fort', state: 'Rajasthan', category: 'Heritage', description: 'A majestic hilltop fort known for its artistic Hindu-style elements, large ramparts, and series of gates that overlook the Maota Lake near Jaipur.', searchQuery: 'Amer Fort Jaipur Rajasthan', loves: 11200, season: 'Winter' },
    { id: 206, name: 'Red Fort', state: 'Delhi', category: 'Heritage', description: 'The historic residence of Mughal emperors, this red sandstone fortress stands as a symbol of Indian sovereignty and architectural brilliance.', searchQuery: 'Red Fort Delhi heritage', loves: 14100, season: 'Winter' },
    { id: 207, name: 'Ellora Caves', state: 'Maharashtra', category: 'Heritage', description: 'A massive rock-cut monastery-temple complex featuring Hindu, Buddhist, and Jain monuments, including the monolithic Kailasa Temple.', searchQuery: 'Ellora Caves Aurangabad', loves: 9800, season: 'Autumn' },
    { id: 208, name: 'Victoria Memorial', state: 'West Bengal', category: 'Heritage', description: 'A large marble building in Kolkata dedicated to Queen Victoria, surrounded by lush gardens and reflecting the city colonial history.', searchQuery: 'Victoria Memorial Kolkata', loves: 10500, season: 'Winter' },
    { id: 209, name: 'Meenakshi Temple', state: 'Tamil Nadu', category: 'Spiritual', description: 'A historic Hindu temple on the southern bank of the Vaigai River, renowned for its towering gopurams covered in thousands of colorful figures.', searchQuery: 'Meenakshi Amman Temple Madurai', loves: 11900, season: 'Winter' },
    { id: 210, name: 'Pangong Tso', state: 'Ladakh', category: 'Nature', description: 'A breathtaking high-altitude lake that changes colors from azure to green, made famous by cinematic landscapes and its serene Himalayan backdrop.', searchQuery: 'Pangong Lake Ladakh', loves: 16700, season: 'Summer' },
    { id: 211, name: 'Jog Falls', state: 'Karnataka', category: 'Nature', description: 'The second-highest plunge waterfall in India, where the Sharavathi River drops nearly 830 feet in a magnificent display of nature power.', searchQuery: 'Jog Falls Karnataka waterfall', loves: 8400, season: 'Monsoon' },
    { id: 212, name: 'Sanchi Stupa', state: 'Madhya Pradesh', category: 'Heritage', description: 'One of the oldest stone structures in India, this Buddhist monument is a testament to the Mauryan empire and ancient Indian artistry.', searchQuery: 'Sanchi Stupa heritage', loves: 7600, season: 'Winter' },
    { id: 213, name: 'Mysore Palace', state: 'Karnataka', category: 'Heritage', description: 'An incredibly grand palace that serves as the official residence of the Wadiyar dynasty, stunningly illuminated by thousands of bulbs on Sundays.', searchQuery: 'Mysore Palace Karnataka', loves: 12300, season: 'Autumn' },
    { id: 214, name: 'Valley of Flowers', state: 'Uttarakhand', category: 'Nature', description: 'A high-altitude Himalayan valley known for its meadows of endemic alpine flowers and outstanding natural beauty in a vibrant ecosystem.', searchQuery: 'Valley of Flowers trek', loves: 9200, season: 'Monsoon' },
    { id: 215, name: 'Sundarbans', state: 'West Bengal', category: 'Nature', description: 'The largest mangrove forest in the world, home to the Royal Bengal Tiger and a unique ecosystem of tidal waterways and mudflats.', searchQuery: 'Sundarbans tiger reserve', loves: 8900, season: 'Winter' },
    { id: 216, name: 'Golden Temple', state: 'Punjab', category: 'Spiritual', description: 'The holiest Gurdwara of Sikhism, offering spiritual solace and the world largest free community kitchen (langar) to all visitors.', searchQuery: 'Golden Temple Amritsar', loves: 18500, season: 'Winter' },
    { id: 217, name: 'Jaisalmer Fort', state: 'Rajasthan', category: 'Heritage', description: 'A living fort standing amidst the sandy expanse of the Thar Desert, built from yellow sandstone that glows like gold at sunset.', searchQuery: 'Jaisalmer Golden Fort', loves: 10200, season: 'Winter' },
    { id: 218, name: 'Living Root Bridges', state: 'Meghalaya', category: 'Nature', description: 'Ancient bio-engineering wonders where the roots of rubber trees are trained by locals to form sturdy bridges across mountain streams.', searchQuery: 'Meghalaya root bridges', loves: 11400, season: 'Monsoon' },
    { id: 219, name: 'Konark Sun Temple', state: 'Odisha', category: 'Heritage', description: 'A 13th-century temple shaped like a giant chariot with intricately carved wheels, dedicated to the Sun God, Surya.', searchQuery: 'Konark Sun Temple Odisha', loves: 9500, season: 'Winter' },
    { id: 220, name: 'Chitrakote Falls', state: 'Chhattisgarh', category: 'Nature', description: 'Often called the Niagara Falls of India, it is the widest waterfall in the country, especially majestic during the monsoon season.', searchQuery: 'Chitrakote falls Chhattisgarh', loves: 7100, season: 'Monsoon' }
];

const collections = [
    { id: 301, title: 'Monsoon Magic', description: 'Experience the raw beauty of India as it turns emerald green. From the waterfalls of the Western Ghats to the mist-covered hills of Meghalaya, these destinations are best enjoyed under the rhythmic rain.', searchQuery: 'monsoon rain mountains waterfalls', type: 'seasonal' },
    { id: 302, title: 'Summer Escape', description: 'Ditch the scorching heat of the plains for the cool, crisp air of the Himalayas and high-altitude stations. Think apple orchards, snow-capped peaks, and refreshing mountain streams.', searchQuery: 'summer mountains cool breeze hill stations', type: 'seasonal' },
    { id: 303, title: 'Winter Wanderlust', description: 'The perfect time for golden sands and historical exploration. Enjoy the pleasant weather of the desert palaces or soak up the sun on India’s tropical southern coastlines.', searchQuery: 'winter beach tropical desert heritage', type: 'seasonal' },
    { id: 304, title: 'Spiritual Sojourn', description: 'A collection of India’s most sacred cities and temples, where ancient rituals and peaceful chants provide a deep sense of calm and cultural immersion.', searchQuery: 'temples spiritual pilgrimage india', type: 'curated' },
    { id: 305, title: 'Wildlife Chronicles', description: 'Venture into the heart of India’s densest jungles. Track the Royal Bengal Tiger, observe one-horned rhinos, and discover a world of rare birds and untamed nature.', searchQuery: 'wildlife safari tiger reserve national park', type: 'curated' },
    { id: 306, title: 'Heritage Trails', description: 'Journey back in time through architectural marvels, ancient ruins, and royal palaces that tell the story of India’s glorious and diverse history.', searchQuery: 'heritage sites monuments history', type: 'curated' }
];

const faqs = [
    { question: 'What is the best time to visit India?', answer: 'Each destination has its own charm. Generally, October to March (Winter) is ideal for most locations like Rajasthan and the beaches. However, the Himalayas are best in Summer (April to June), and the Western Ghats are stunning during the Monsoon (July to September).' },
    { question: 'Do I need special permits for certain areas?', answer: 'Most locations are open to tourists. However, restricted areas like parts of Ladakh, Arunachal Pradesh, and the Andaman Islands may require an Inner Line Permit (ILP) or Protected Area Permit (PAP) for both Indian and foreign nationals.' },
    { question: 'What are the accommodation options?', answer: 'India offers a massive range of stays, from budget-friendly hostels and homestays to luxury heritage palaces and eco-resorts. In remote areas, guesthouses and government forest lodges are common.' },
    { question: 'How do I get around between cities?', answer: 'India has one of the world’s largest railway networks, which is the most popular way to travel. For longer distances, domestic flights are frequent. Local travel is best handled via taxis, auto-rickshaws, or app-based services like Uber and Ola.' },
    { question: 'Is it safe for solo travelers?', answer: 'Yes, India is generally safe for solo travelers. We recommend staying in well-reviewed accommodations, using official transport, and being mindful of local customs and dress codes, especially at religious sites.' },
    { question: 'What should I pack for a mountain trip?', answer: 'Even in summer, mountain temperatures can drop at night. Pack layers including a light jacket, sturdy trekking shoes, sunscreen, and any personal medications, as pharmacies can be far apart in high-altitude regions.' },
    { question: 'Are vegetarian food options easily available?', answer: 'Absolutely! India has one of the highest populations of vegetarians in the world. You will find a vast and delicious variety of vegetarian dishes in every corner of the country.' },
    { question: 'Is digital payment widely accepted?', answer: 'Yes, most urban areas and tourist hubs widely accept UPI (like GPay or PhonePe) and cards. However, it is always wise to carry some cash when traveling to rural or remote mountain regions.' }
];

// Fetch image from Pexels with optional orientation
async function fetchPexelsImage(query, orientation = '') {
    const cacheKey = orientation ? `${query}_${orientation}` : query;
    if (imageCache[cacheKey]) {
        return imageCache[cacheKey];
    }
    try {
        const url = `${PEXELS_API}?query=${encodeURIComponent(query)}&per_page=1${orientation ? '&orientation=' + orientation : ''}`;
        const response = await fetch(url, {
            headers: { 'Authorization': PEXELS_API_KEY }
        });
        const data = await response.json();
        if (data.photos && data.photos.length > 0) {
            const imageUrl = data.photos[0].src.large;
            imageCache[cacheKey] = imageUrl;
            return imageUrl;
        }
        return 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300"><rect fill="%23e2e8f0" width="400" height="300"/></svg>';
    } catch (error) {
        console.error('Error fetching image:', error);
        return 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300"><rect fill="%23e2e8f0" width="400" height="300"/></svg>';
    }
}

async function createLocationCard(location) {
    const image = await fetchPexelsImage(location.searchQuery);
    return `
                <div class="location-card">
                    <div class="card-inner">
                        <div class="card-front">
                            <div class="card-image-wrapper">
                                <img src="${image}" alt="${location.name}" class="card-image" loading="lazy">
                                <span class="card-badge">${location.category}</span>
                            </div>
                            <div class="card-content">
                                <div class="card-header">
                                    <h3 class="card-title">${location.name}</h3>
                                    <span class="card-package-qty">${location.packageQty || 0} Pkgs</span>
                                </div>
                                <div class="card-region">
                                    <i class="fas fa-map-pin"></i>
                                    <span>${location.city ? location.city + ', ' : ''}${location.state || 'India'}</span>
                                </div>
                            </div>
                        </div>
                        <div class="card-back">
                            <h3 class="card-back-title">${location.name}</h3>
                            <p class="card-description">${location.description}</p>
                            <button class="cta-button" style="padding: 0.5rem 1.5rem; font-size: 0.85rem;">View Details</button>
                        </div>
                    </div>
                </div>
            `;
}

async function createOfferCard(collection) {
    const image = await fetchPexelsImage(collection.searchQuery);
    return `
<div class="offer-card-v2" style="background-image: url('${image}');">
    <div class="offer-overlay">
        <span class="offer-tag-v2">${collection.type}</span>
        <h3 class="offer-title-v2">${collection.title}</h3>
        <p class="offer-description-v2">${collection.description}</p>
    </div>
</div>
            `;
}

async function createMostLovedCard(location) {
    const image = await fetchPexelsImage(location.searchQuery);
    return `
                <div class="loved-card" style="background-image: url('${image}');">
                    <div class="loved-overlay">
                        <h3 class="loved-title">${location.name}</h3>
                        <p class="loved-description">${location.description}</p>
                        <div class="loved-count">
                            <i class="fas fa-heart"></i>
                            <span>${(location.loves / 1000).toFixed(1)}k loves</span>
                        </div>
                    </div>
                </div>
            `;
}

function toggleLike(btn) {
    btn.classList.toggle('liked');
    const icon = btn.querySelector('i');
    if (btn.classList.contains('liked')) {
        icon.className = 'fas fa-heart';
    } else {
        icon.className = 'far fa-heart';
    }
}

function toggleFilters() {
    document.getElementById('filtersSection').classList.toggle('active');
}

async function applyFilters() {
    const categoryInput = document.querySelector('input[name="category"]:checked');
    const category = categoryInput ? categoryInput.value : 'All';
    const state = document.getElementById('stateFilter').value;
    const query = document.getElementById('destinationSearch')?.value.toLowerCase() || '';

    const selectedSeasons = Array.from(document.querySelectorAll('.filter-chip input[type="checkbox"]:checked'))
        .map(cb => cb.value);

    filteredDestinations = destinationsData.filter(d => {
        const categoryMatch = category === 'All' || d.category === category;
        const stateMatch = state === 'All' || d.state === state;
        const searchMatch = !query ||
            d.name.toLowerCase().includes(query) ||
            d.city.toLowerCase().includes(query) ||
            d.state.toLowerCase().includes(query);
        const seasonMatch = selectedSeasons.length === 0 || selectedSeasons.includes(d.season);

        return categoryMatch && stateMatch && searchMatch && seasonMatch;
    });

    currentPage = 1;
    await renderLocations();
    await renderMostLoved(query);
}

function resetFilters() {
    const allRadio = document.getElementById('cat-all');
    if (allRadio) allRadio.checked = true;

    const stateFilter = document.getElementById('stateFilter');
    if (stateFilter) stateFilter.value = 'All';

    const searchInput = document.getElementById('destinationSearch');
    if (searchInput) searchInput.value = '';

    document.querySelectorAll('.filter-chip input[type="checkbox"]').forEach(cb => cb.checked = false);

    applyFilters();
}

async function renderLocations() {
    const grid = document.getElementById('locationsGrid');
    if (!grid) return;

    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const current = filteredDestinations.slice(start, end);

    if (current.length === 0) {
        grid.innerHTML = `
                    <div style="grid-column: 1/-1;">
                        <div class="empty-state">
                            <div class="empty-icon"><i class="fas fa-search"></i></div>
                            <h3 class="empty-title">No locations found</h3>
                            <p class="empty-description">Try adjusting your filters</p>
                        </div>
                    </div>
                `;
        const pagination = document.getElementById('pagination');
        if (pagination) pagination.innerHTML = '';
        return;
    }

    let html = '';
    for (const loc of current) {
        html += `<div class="swiper-slide">${await createLocationCard(loc)}</div>`;
    }
    grid.innerHTML = html;
    const resultsCount = document.getElementById('resultsCount');
    if (resultsCount) resultsCount.textContent = filteredDestinations.length;
    renderPagination();

    // Re-init mobile swiper after content update
    initLocationsSwiper();
}

function renderPagination() {
    const total = Math.ceil(filteredDestinations.length / itemsPerPage);
    const pagination = document.getElementById('pagination');

    if (total <= 1) {
        pagination.innerHTML = '';
        return;
    }

    let html = `<button ${currentPage === 1 ? 'disabled' : ''} onclick="previousPage()"><i class="fas fa-chevron-left"></i></button>`;

    for (let i = 1; i <= total; i++) {
        html += `<button class="${i === currentPage ? 'active' : ''}" onclick="goToPage(${i})">${i}</button>`;
    }

    html += `<button ${currentPage === total ? 'disabled' : ''} onclick="nextPage()"><i class="fas fa-chevron-right"></i></button>`;
    pagination.innerHTML = html;
}

function previousPage() {
    if (currentPage > 1) {
        currentPage--;
        renderLocations();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

function nextPage() {
    const total = Math.ceil(filteredDestinations.length / itemsPerPage);
    if (currentPage < total) {
        currentPage++;
        renderLocations();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

function goToPage(page) {
    currentPage = page;
    renderLocations();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function renderSwipers() {
    let similar = '';
    for (const d of similarDestinations) {
        similar += `<div class="swiper-slide">${await createLocationCard(d)}</div>`;
    }
    const similarWrapper = document.getElementById('similarWrapper');
    if (similarWrapper) similarWrapper.innerHTML = similar;

    let collections_html = '';
    for (const c of collections) {
        collections_html += `<div class="swiper-slide">${await createOfferCard(c)}</div>`;
    }
    const collectionsWrapper = document.getElementById('collectionsWrapper');
    if (collectionsWrapper) collectionsWrapper.innerHTML = collections_html;
}

async function renderMostLoved(query = '') {
    let data = [...mostLovedDestinations];

    if (query) {
        const lowerQuery = query.toLowerCase();
        data = data.filter(d =>
            d.name.toLowerCase().includes(lowerQuery) ||
            d.state.toLowerCase().includes(lowerQuery) ||
            d.description.toLowerCase().includes(lowerQuery) ||
            (d.searchQuery && d.searchQuery.toLowerCase().includes(lowerQuery))
        );
    }

    const displayData = data.sort(() => Math.random() - 0.5).slice(0, 4);

    let html = '';
    for (const d of displayData) {
        html += `<div>${await createMostLovedCard(d)}</div>`;
    }
    const grid = document.getElementById('mostLovedGrid');
    if (grid) grid.innerHTML = html;
}

async function renderSeasons() {
    const seasonsGrid = document.getElementById('seasonsGrid');
    if (!seasonsGrid) return;

    const seasons = [
        { name: 'Spring', query: 'cherry blossom spring flowers' },
        { name: 'Summer', query: 'tropical beach sunny summer' },
        { name: 'Monsoon', query: 'monsoon rain nature forest' },
        { name: 'Autumn', query: 'autumn maple leaves park' },
        { name: 'Winter', query: 'winter snow mountains' }
    ];

    let html = '';
    for (const s of seasons) {
        const img = await fetchPexelsImage(s.query);
        html += `
                    <div class="swiper-item">
                        <div class="season-circle-card">
                            <div class="season-circle-img">
                                <img src="${img}" alt="${s.name}">
                            </div>
                            <h3 class="season-name">${s.name}</h3>
                        </div>
                    </div>
                `;
    }
    seasonsGrid.innerHTML = html;
}

function renderFAQ() {
    const faqContainer = document.getElementById('faqContainer');
    if (!faqContainer) return;

    let html = '';
    for (let i = 0; i < faqs.length; i++) {
        html += `
                    <div class="faq-item">
                        <button class="faq-question" onclick="toggleFAQ(${i})">
                            <span>${faqs[i].question}</span>
                            <span class="faq-toggle" id="toggle-${i}">+</span>
                        </button>
                        <div class="faq-answer" id="answer-${i}">${faqs[i].answer}</div>
                    </div>
                `;
    }
    faqContainer.innerHTML = html;
}

function toggleFAQ(i) {
    document.getElementById(`answer-${i}`).classList.toggle('open');
    document.getElementById(`toggle-${i}`).classList.toggle('open');
}

function toggleMobileFilters() {
    const filters = document.getElementById('filtersSection');
    const overlay = document.getElementById('filtersOverlay');
    if (!filters || !overlay) return;

    filters.classList.toggle('show-mobile');
    overlay.classList.toggle('show');
    document.body.style.overflow = filters.classList.contains('show-mobile') ? 'hidden' : '';
}

const promoOffers = [
    {
        title: "Bali Getaway",
        desc: "Experience the spiritual heart of Indonesia with our exclusive 5-day package.",
        badge: "Special Offer",
        discount: "30% OFF",
        query: "Bali beach resort",
        oldPrice: "₹45,000",
        newPrice: "₹32,999"
    },
    {
        title: "Swiss Alps Tour",
        desc: "Discover the breathtaking beauty of the snow-capped mountains and crystal lakes.",
        badge: "Limited Deal",
        discount: "25% OFF",
        query: "Swiss Alps mountains",
        oldPrice: "₹1,20,000",
        newPrice: "₹89,999"
    },
    {
        title: "Rajasthan Heritage",
        desc: "Walk through the royal palaces and golden deserts of incredible Rajasthan.",
        badge: "Premium Offer",
        discount: "40% OFF",
        query: "Rajasthan palace",
        oldPrice: "₹35,000",
        newPrice: "₹24,500"
    },
    {
        title: "Maldives Escape",
        desc: "Stay in a private overwater villa and enjoy the pristine turquoise waters.",
        badge: "Luxury Deal",
        discount: "20% OFF",
        query: "Maldives overwater villa",
        oldPrice: "₹95,000",
        newPrice: "₹68,000"
    }
];

let currentPromoIndex = 0;

async function updateDynamicPromo() {
    const promo = promoOffers[currentPromoIndex];
    const promoEl = document.getElementById('dynamicPromo');
    const imgEl = document.getElementById('promoImg');
    const titleEl = document.getElementById('promoTitle');
    const descEl = document.getElementById('promoDesc');
    const badgeEl = document.getElementById('promoBadge');
    const discountEl = document.getElementById('promoDiscount');
    const oldPriceEl = document.getElementById('promoOldPrice');
    const newPriceEl = document.getElementById('promoNewPrice');

    if (!promoEl || !imgEl) return;

    promoEl.style.opacity = '0.7';

    try {
        const imageUrl = await fetchPexelsImage(promo.query, 'landscape');
        imgEl.src = imageUrl;
    } catch (error) {
        console.error("Error fetching promo image:", error);
    }

    titleEl.textContent = promo.title;
    descEl.textContent = promo.desc;
    badgeEl.textContent = promo.badge;
    discountEl.textContent = promo.discount;
    oldPriceEl.textContent = promo.oldPrice;
    newPriceEl.textContent = promo.newPrice;

    promoEl.style.opacity = '1';

    const timerEl = document.getElementById('promoTimer');
    if (timerEl) {
        timerEl.classList.remove('promo-timer-animate');
        void timerEl.offsetWidth;
        timerEl.classList.add('promo-timer-animate');
    }

    currentPromoIndex = (currentPromoIndex + 1) % promoOffers.length;
}

const customers = ["Aarav Sharma", "Ananya Iyer", "Vikram Singh", "Priya Patel", "Rahul Gupta", "Sanya Mirza", "Deepak Roy", "Meera Krishnan"];
const salesPackages = ["Misty Shimla Retreat", "Royal Rajasthan Tour", "Kerala Backwaters Bliss", "Goa Beach Party", "Leh Ladakh Adventure", "Varanasi Spiritual Journey"];
const salesQueries = ["Shimla hills", "Jaipur palace", "Kerala houseboat", "Goa beach", "Leh mountains", "Varanasi temple"];

async function showSalesToast() {
    const toast = document.getElementById('salesToast');
    if (!toast) return;

    const name = customers[Math.floor(Math.random() * customers.length)];
    const pkgIdx = Math.floor(Math.random() * salesPackages.length);
    const pkgName = salesPackages[pkgIdx];
    const img = await fetchPexelsImage(salesQueries[pkgIdx]);

    document.getElementById('toastImg').src = img;
    document.getElementById('toastName').innerText = name;
    document.getElementById('toastPackage').innerText = pkgName;
    document.getElementById('toastTime').innerText = `${Math.floor(Math.random() * 50 + 10)} seconds ago`;

    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
    }, 6000);
}

function closeToast() {
    document.getElementById('salesToast').classList.remove('show');
}

// Initialize Everything
async function init() {
    filteredDestinations = destinationsData;

    const heroImg = await fetchPexelsImage('scenic travel mountain landscape');
    const heroEl = document.querySelector('.hero');
    if (heroEl) heroEl.style.backgroundImage = `url(${heroImg})`;

    await renderLocations();
    await renderSwipers();
    await renderMostLoved();
    await renderSeasons();
    renderFAQ();

    setTimeout(() => {
        showSalesToast();
        setInterval(showSalesToast, 18000);
    }, 5000);

    const promoContainer = document.getElementById('dynamicPromo');
    if (promoContainer) {
        const delay = parseInt(promoContainer.dataset.delay) || 5000;
        updateDynamicPromo();
        setInterval(updateDynamicPromo, delay);
    }

    new Swiper('.brand-swiper', {
        slidesPerView: 2,
        spaceBetween: 50,
        loop: true,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        breakpoints: {
            640: { slidesPerView: 3 },
            768: { slidesPerView: 4 },
            1024: { slidesPerView: 5 },
        }
    });

    // Init Swipers
    initLocationsSwiper();

    // Init Recommended & Collections swipers
    window._similarSwiper = new Swiper('#similarContainer', {
        slidesPerView: 1,
        spaceBetween: 24,
        breakpoints: {
            640: { slidesPerView: 2, spaceBetween: 20 },
            1024: { slidesPerView: 3, spaceBetween: 24 },
            1400: { slidesPerView: 4, spaceBetween: 24 }
        }
    });

    window._collectionsSwiper = new Swiper('#collectionsContainer', {
        slidesPerView: 1,
        spaceBetween: 24,
        breakpoints: {
            640: { slidesPerView: 2, spaceBetween: 20 },
            1024: { slidesPerView: 3, spaceBetween: 24 }
        }
    });
}

function scrollSwiper(type, dir) {
    const swiper = type === 'similar' ? window._similarSwiper
        : type === 'collections' ? window._collectionsSwiper
            : null;
    if (!swiper) return;
    if (dir === 'left') swiper.slidePrev();
    else swiper.slideNext();
}

// Mobile locations swiper (< 576px only)
let _locationsSwiper = null;
function initLocationsSwiper() {
    const wrap = document.getElementById('locationsSwiperWrap');
    const grid = document.getElementById('locationsGrid');
    const pagination = document.getElementById('pagination');
    if (!wrap || !grid) return;

    if (window.innerWidth < 576) {
        // Add swiper classes if not already
        if (!wrap.classList.contains('swiper')) {
            wrap.classList.add('swiper');
            grid.classList.add('swiper-wrapper');
        }
        // Hide pagination on mobile
        if (pagination) pagination.style.display = 'none';

        // Destroy previous instance before re-init
        if (_locationsSwiper) {
            _locationsSwiper.destroy(true, true);
            _locationsSwiper = null;
        }
        _locationsSwiper = new Swiper('#locationsSwiperWrap', {
            slidesPerView: 1.12,
            spaceBetween: 16,
            centeredSlides: true,
            loop: false,
            grabCursor: true,
            speed: 400,
        });
    } else {
        // Desktop: destroy swiper and restore grid classes
        if (_locationsSwiper) {
            _locationsSwiper.destroy(true, true);
            _locationsSwiper = null;
        }
        wrap.classList.remove('swiper');
        grid.classList.remove('swiper-wrapper');
        if (pagination) pagination.style.display = '';
    }
}

window.addEventListener('resize', initLocationsSwiper);

init();
document.addEventListener('DOMContentLoaded', function () {
    const tabs = document.querySelectorAll('.svc-tab');
    const heroBg = document.getElementById('heroBg');
    const heroTitle = document.getElementById('heroTitle');
    const heroSub = document.getElementById('heroSub');
    const allPanels = document.querySelectorAll('.panel');

    tabs.forEach(tab => {
        tab.addEventListener('click', function () {
            const key = this.getAttribute('data-tab');
            const img = this.getAttribute('data-img');
            const title = this.getAttribute('data-title');
            const sub = this.getAttribute('data-sub');

            console.log('Tab clicked:', key);

            // 1. Update tabs visual state
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');

            // 2. Swap background image
            if (heroBg && img) {
                heroBg.style.backgroundImage = `url('${img}')`;
            }

            // 3. Swap text content if elements exist
            if (heroTitle && title) heroTitle.textContent = title;
            if (heroSub && sub) heroSub.textContent = sub;

            // 4. Swap panels
            const targetPanel = document.getElementById('panel-' + key);
            if (targetPanel) {
                allPanels.forEach(p => p.classList.remove('active'));
                targetPanel.classList.add('active');
            }

            // 5. Update global search button text (Mobile)
            const mobileSearchBtn = document.getElementById('mobileSearchBtn');
            const mobileAiBadge = document.getElementById('mobileAiBadge');

            if (mobileSearchBtn) {
                let btnText = '<i class="fa-solid fa-magnifying-glass"></i> Search';
                if (key === 'flight') btnText = '<i class="fa-solid fa-magnifying-glass"></i> Search Flights';
                if (key === 'hotel') btnText = '<i class="fa-solid fa-magnifying-glass"></i> Search Hotels';
                if (key === 'holiday') btnText = '<i class="fa-solid fa-magnifying-glass"></i> Explore Packages';
                if (key === 'hptdc') btnText = '<i class="fa-solid fa-mountain"></i> View Packages';
                if (key === 'cruise') btnText = '<i class="fa-solid fa-ship"></i> Search Cruises';
                mobileSearchBtn.innerHTML = btnText;
            }

            if (mobileAiBadge) {
                let badgeText = '<i class="fa-solid fa-wand-magic-sparkles"></i> AI Assistant';
                if (key === 'flight') badgeText = '<i class="fa-solid fa-wand-magic-sparkles"></i> AI Assistant for Flights';
                if (key === 'hotel') badgeText = '<i class="fa-solid fa-wand-magic-sparkles"></i> AI Assistant for Stays';
                if (key === 'holiday') badgeText = '<i class="fa-solid fa-wand-magic-sparkles"></i> AI Curated';
                if (key === 'hptdc') badgeText = '<i class="fa-solid fa-wand-magic-sparkles"></i>Special offers!';
                if (key === 'cruise') badgeText = '<i class="fa-solid fa-wand-magic-sparkles"></i> AI Curated';

                mobileAiBadge.innerHTML = badgeText;
                mobileAiBadge.style.display = badgeText ? '' : 'none';
            }
        });
    });
});

// Trip pill toggle (flights)
document.querySelectorAll('.trip-pills').forEach(group => {
    group.querySelectorAll('.trip-pill').forEach(pill => {
        pill.addEventListener('click', function () {
            group.querySelectorAll('.trip-pill').forEach(p => p.classList.remove('active'));
            this.classList.add('active');

            // Toggle swap button and return field based on 'Round Trip'
            const isRoundTrip = this.textContent.trim().toLowerCase() === 'round trip';
            const swapBtn = document.querySelector('.swap-btn');
            const returnField = document.querySelector('#panel-flight .field-group:nth-child(5) .field-display');

            if (isRoundTrip) {
                swapBtn?.classList.remove('hidden-pill');
                if (returnField) {
                    returnField.classList.remove('field-dim');
                    returnField.querySelector('.field-main').textContent = 'Select Date';
                    returnField.querySelector('.field-sub').textContent = 'Choose return';
                }
            } else {
                swapBtn?.classList.add('hidden-pill');
                if (returnField) {
                    returnField.classList.add('field-dim');
                    returnField.querySelector('.field-main').textContent = 'Add Date';
                    returnField.querySelector('.field-sub').textContent = 'For round trip';
                }
            }
        });
    });
});

// Fare chip toggle
document.querySelectorAll('.fare-chip').forEach(chip => {
    chip.addEventListener('click', () => {
        document.querySelectorAll('.fare-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
    });
});

// Swap button animation
document.querySelector('.swap-btn')?.addEventListener('click', function () {
    const fromEl = document.querySelector('#panel-flight .booking-fields .field-group:first-child');
    // just visual demo — in production you'd swap the input values
    this.style.transform = 'rotate(180deg)';
    setTimeout(() => this.style.transform = '', 400);
});

// Mobile Drawer Logic
const menuToggle = document.getElementById('menuToggle');
const drawerClose = document.getElementById('drawerClose');
const mobileDrawer = document.getElementById('mobileDrawer');
const drawerOverlay = document.getElementById('drawerOverlay');

const toggleDrawer = (open) => {
    if (open) {
        mobileDrawer.classList.add('active');
        drawerOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    } else {
        mobileDrawer.classList.remove('active');
        drawerOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }
};

menuToggle?.addEventListener('click', () => toggleDrawer(true));
drawerClose?.addEventListener('click', () => toggleDrawer(false));
drawerOverlay?.addEventListener('click', () => toggleDrawer(false));

// Mobile Trip Dropdown Logic
const tripDropdownMobile = document.getElementById('tripDropdownMobile');
const tripValMobile = document.getElementById('tripValMobile');
const fareDropdownMobile = document.getElementById('fareDropdownMobile');
const fareValMobile = document.getElementById('fareValMobile');

tripDropdownMobile?.addEventListener('change', function () {
    const val = this.value.toLowerCase();
    if (tripValMobile) tripValMobile.textContent = this.options[this.selectedIndex].text;

    const isRoundTrip = val === 'round trip';
    const swapBtn = document.querySelector('.swap-btn');
    const returnField = document.querySelector('#panel-flight .field-group:nth-child(5) .field-display');

    if (isRoundTrip) {
        swapBtn?.classList.remove('hidden-pill');
        if (returnField) {
            returnField.classList.remove('field-dim');
            returnField.querySelector('.field-main').textContent = 'Select Date';
            returnField.querySelector('.field-sub').textContent = 'Choose return';
        }
    } else {
        swapBtn?.classList.add('hidden-pill');
        if (returnField) {
            returnField.classList.add('field-dim');
            returnField.querySelector('.field-main').textContent = 'Add Date';
            returnField.querySelector('.field-sub').textContent = 'For round trip';
        }
    }
});

fareDropdownMobile?.addEventListener('change', function () {
    if (fareValMobile) fareValMobile.textContent = this.options[this.selectedIndex].text;
});
