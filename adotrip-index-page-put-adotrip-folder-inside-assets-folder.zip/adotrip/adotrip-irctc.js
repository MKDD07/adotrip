const luxuryTrainData = {
  goldenChariot: {
    key: 'goldenChariot',
    title: "Golden Chariot",
    subtitle: "Pride of Karnataka",
    description: "Journey through the jewels of South India aboard the golden-hued luxury train, tracing ancient kingdoms, wildlife, and coastal splendour.",
    duration: "6 Nights / 7 Days",
    route: "Bengaluru → Bandipur → Mysore → Halebidu → Chikmagalur → Hampi → Pattadakal & Aihole → Goa → Bengaluru",
    image: "https://images.unsplash.com/photo-1501854140801-50d01698950b?w=600&q=80",
    color: {
      primary: '#701471',
      accent: '#E9C7EA',
      border: '#B96ABB',
      mutedBg: '#F8EEF8'
    },
    logo: "https://www.goldenchariot.org/assets/img/logo.png",
    highlights: ["Luxury Cabins", "Fine Dining", "Guided Tours", "Premium Hospitality", "Multi-city Journey"],
    itinerary: [
      { day: "Day 01", destination: "Bengaluru", image: "https://images.unsplash.com/photo-1596176530529-78163a4f7af2?w=400&q=80", text: "Board the Golden Chariot at Yeshwantpur Station. Welcome ceremony, orientation lunch onboard, then an afternoon drive to Bandipur Wildlife Sanctuary for an evening jeep safari.", tags: ["Welcome Lunch", "Onboarding", "Evening Safari"] },
      { day: "Day 02", destination: "Mysore", image: "https://images.unsplash.com/photo-1567157577867-05ccb1388e66?w=400&q=80", text: "Explore the magnificent Mysore Palace, silk weaving centres, and the fragrant sandalwood bazaars. Optional visit to Srirangapatnam. Evening return to the train for a South Indian banquet.", tags: ["Palace Visit", "Heritage Walk", "Silk Emporium"] },
      { day: "Day 03", destination: "Halebidu & Chikmagalur", image: "https://images.unsplash.com/photo-1535941339077-2dd1c7963098?w=400&q=80", text: "Visit the stunning Hoysala temples at Halebidu and Belur — masterpieces of 12th-century architecture. Afternoon drive through the misty coffee estates of Chikmagalur.", tags: ["Hoysala Temples", "Coffee Estates", "Heritage"] },
      { day: "Day 04", destination: "Hampi", image: "https://images.unsplash.com/photo-1590077428593-a55bb07c4665?w=400&q=80", text: "UNESCO World Heritage Site Hampi unfolds its boulder-strewn glory. Visit the Vijayvithala Temple complex with its iconic stone chariot — the very inspiration behind the Golden Chariot's name.", tags: ["UNESCO Site", "Archaeology", "Photography"] },
      { day: "Day 05", destination: "Pattadakal & Aihole", image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&q=80", text: "Explore the cave temples of Badami, the twin shrines at Aihole, and the grand Pattadakal temples — the cradle of South Indian temple architecture.", tags: ["Cave Temples", "Chalukya Art", "Guided Tour"] },
      { day: "Day 06", destination: "Goa", image: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=400&q=80", text: "Arrive on the sunlit Konkan coast. Explore Old Goa's Portuguese churches, spice plantations, and pristine beaches. Farewell dinner on the Arabian Sea shores.", tags: ["Heritage Churches", "Spice Tour", "Beach"] },
      { day: "Day 07", destination: "Return to Bengaluru", image: "https://images.unsplash.com/photo-1596176530529-78163a4f7af2?w=400&q=80", text: "An overnight journey back to Bengaluru. Disembark at Yeshwantpur Station after a leisurely farewell breakfast, carrying memories of the golden southern odyssey.", tags: ["Farewell Breakfast", "Disembarkation"] }
    ],
    // NOTE: Golden Chariot offers only ONE cabin category — Deluxe Cabin (twin or double bed).
    // There are no Junior Suite or Presidential Suite tiers on this train.
    pricing: [
      { tier: "Deluxe Cabin (Twin Sharing)", inr: "₹3,98,160", usd: "$4,740", featured: true, features: ["Twin or double bedded cabin", "All meals included", "Guided excursions & entry fees", "Butler service", "Spa & gym access", "Two onboard restaurants"] },
      { tier: "Single Supplement", inr: "₹2,99,040", usd: "$3,560", featured: false, features: ["Private single occupancy", "All meals included", "Guided excursions & entry fees", "Butler service", "Spa & gym access", "Two onboard restaurants"] }
    ]
  },
  buddhaExpress: {
    key: 'buddhaExpress',
    title: "Buddhist Circuit Tourist Train",
    subtitle: "Mahaparinirvan Express",
    description: "Follow the sacred path of the Enlightened One across northern India's ancient heartland, visiting the holiest Buddhist pilgrimage sites in the world.",
    duration: "7 Nights / 8 Days",
    route: "Delhi → Gaya/Bodhgaya → Nalanda/Rajgir → Varanasi/Sarnath → Lumbini (Nepal) → Kushinagar → Sravasti → Agra → Delhi",
    image: "https://images.unsplash.com/photo-1567472604027-1bd1ba4e0706?w=600&q=80",
    color: {
      primary: '#68213B',
      accent: '#E8CCD5',
      border: '#B56A84',
      mutedBg: '#F8EFF2'
    },
    logo: "assets/adotrip/logo",
    highlights: ["Spiritual Pilgrimage", "Expert Guides", "Sacred Site Access", "Meditation Sessions", "Multi-city Journey"],
    itinerary: [
      { day: "Day 01", destination: "Delhi", image: "https://images.unsplash.com/photo-1587474260584-136574528ed5?w=400&q=80", text: "Assemble at Safdarjung Station by 13:00 hrs. Cultural orientation on the Buddhist circuit, welcome dinner onboard, and departure at 14:30 hrs for Gaya.", tags: ["Orientation", "Welcome Dinner", "Departure"] },
      { day: "Day 02", destination: "Bodhgaya", image: "https://images.unsplash.com/photo-1567472604027-1bd1ba4e0706?w=400&q=80", text: "Arrive at the holiest Buddhist site. Visit the Mahabodhi Temple — a UNESCO World Heritage Site — and meditate beneath the sacred Bodhi Tree. Depart for Rajgir & Nalanda in the afternoon.", tags: ["UNESCO Site", "Mahabodhi Temple", "Bodhi Tree"] },
      { day: "Day 03", destination: "Nalanda & Rajgir", image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80", text: "Explore the ruins of Nalanda Mahavihara, the world's oldest residential university. Cable car ascent to Vishwa Shanti Stupa at Rajgir's Ratnagiri Hill. Visit Venuvana, the bamboo grove of the Buddha.", tags: ["Ancient University", "Peace Stupa", "Cable Car"] },
      { day: "Day 04", destination: "Varanasi & Sarnath", image: "https://images.unsplash.com/photo-1561361058-c24e01ed36a7?w=400&q=80", text: "Morning arrival in Varanasi. Visit Sarnath — where the Buddha delivered his first sermon at the Deer Park. Evening Ganga Aarti boat ride on the sacred river.", tags: ["Ganges Aarti", "Sarnath", "Deer Park"] },
      { day: "Day 05", destination: "Lumbini (Nepal)", image: "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=400&q=80", text: "Travel via Gorakhpur/Nautanwa and cross into Nepal to reach Lumbini — the birthplace of Siddhartha Gautama. Visit the Maya Devi Temple, the sacred garden, and the Ashoka Pillar. Overnight at hotel in Lumbini.", tags: ["Birthplace", "Maya Devi Temple", "Ashoka Pillar"] },
      { day: "Day 06", destination: "Kushinagar", image: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=400&q=80", text: "Return to India and proceed to Kushinagar — the place of the Buddha's Parinirvana. Visit the Reclining Buddha Temple and the Ramabhar Stupa, the cremation site. Return to Gorakhpur to board the train.", tags: ["Parinirvana Site", "Reclining Buddha", "Ramabhar Stupa"] },
      { day: "Day 07", destination: "Sravasti", image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&q=80", text: "Arrive at Balrampur and travel by coach to Sravasti (15 km), where the Buddha spent many years. Visit Jetavana Vihara, Pakki Kuti, and Sahet Mahet. Return to train in the evening for the overnight journey to Agra.", tags: ["Jetavana Vihara", "Pakki Kuti", "Sahet Mahet"] },
      { day: "Day 08", destination: "Agra & Return to Delhi", image: "https://images.unsplash.com/photo-1548013146-72479768bada?w=400&q=80", text: "Morning arrival at Agra. After breakfast onboard, visit the iconic Taj Mahal — one of the Seven Wonders of the World. Return to train by noon and journey to Delhi, arriving at Safdarjung Station by early evening.", tags: ["Taj Mahal", "Pilgrimage Certificate", "Disembarkation"] }
    ],
    // NOTE: This is a semi-luxury IRCTC train, not a full luxury train. Cabin types are
    // AC First Class (1A) and AC 2-Tier (2A). There are no "Suite" or "Presidential Suite" tiers.
    pricing: [
      { tier: "AC 2-Tier (2A)", inr: "₹93,603", usd: "$1,144", featured: false, features: ["2-tier AC berth", "All vegetarian meals", "Group guided tours", "AC road transport", "Travel insurance"] },
      { tier: "AC First Class (1A)", inr: "₹1,11,931", usd: "$1,368", featured: true, features: ["First class AC cabin (2-berth)", "All vegetarian meals", "Group guided tours", "AC road transport", "Travel insurance", "Hotel wash & change at select destinations"] },
      { tier: "Single Supplement (1A)", inr: "₹56,200", usd: "$669", featured: false, features: ["Exclusive lower berth allocation", "All vegetarian meals", "Group guided tours", "AC road transport", "Travel insurance"] }
    ]
  },
  maharajasExpress: {
    key: 'maharajasExpress',
    title: "Maharajas' Express",
    subtitle: "The World's Leading Luxury Train",
    description: "The world's most celebrated luxury train, weaving through the regal palaces, tiger reserves, and imperial cities of Rajputana in unparalleled splendour.",
    duration: "6 Nights / 7 Days",
    // Route below reflects the "Indian Splendour" itinerary (Delhi → Mumbai)
    route: "Delhi → Agra → Ranthambore → Jaipur → Bikaner → Jodhpur → Udaipur → Mumbai",
    image: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=600&q=80",
    color: {
      primary: '#AD211C',
      accent: '#F2C9C7',
      border: '#D06A66',
      mutedBg: '#FBEEEE'
    },
    logo: "https://www.the-maharajas.com/assets/img/logo.png",
    highlights: ["Royal Cabins", "Award-winning Dining", "Tiger Safari", "Exclusive Palace Access", "Multi-city Journey"],
    itinerary: [
      { day: "Day 01", destination: "Delhi", image: "https://images.unsplash.com/photo-1587474260584-136574528ed5?w=400&q=80", text: "Board the Maharajas' Express at Safdarjung Station with a royal welcome ceremony. Check-in by 07:30 hrs, departure at 09:00 hrs. Breakfast and lunch onboard as the train proceeds to Agra.", tags: ["Royal Welcome", "Check-in 07:30", "Live Music"] },
      { day: "Day 02", destination: "Agra", image: "https://images.unsplash.com/photo-1548013146-72479768bada?w=400&q=80", text: "Sunrise visit to the Taj Mahal — a pre-opening champagne breakfast at Taj Khema. Afternoon exploration of the Agra Fort. Optional visits to Itmad-ud-Daula or the Mohabbat the Taj live show.", tags: ["Taj Mahal", "Agra Fort", "Champagne Breakfast"] },
      { day: "Day 03", destination: "Ranthambore", image: "https://images.unsplash.com/photo-1535941339077-2dd1c7963098?w=400&q=80", text: "Exclusive canter and gypsy safaris into Ranthambore Tiger Reserve — one of India's finest tiger habitats. Evening wildlife briefing by the park's chief naturalist.", tags: ["Tiger Safari", "Gypsy Safari", "Wildlife"] },
      { day: "Day 04", destination: "Jaipur", image: "https://images.unsplash.com/photo-1477587458883-47145ed6979e?w=400&q=80", text: "The Pink City in full grandeur. Morning visit to the City Palace Galleries. Afternoon at leisure or optional tours to Jantar Mantar and Hawa Mahal. Exclusive dinner at the legendary Rambagh Palace Hotel.", tags: ["City Palace", "Jantar Mantar", "Rambagh Palace Dinner"] },
      { day: "Day 05", destination: "Bikaner", image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&q=80", text: "Explore the magnificent Junagarh Fort and Lalgarh Palace. Experience a camel safari into the Thar desert with sundowner cocktails at the sand dunes — a quintessential Rajasthan evening.", tags: ["Junagarh Fort", "Camel Safari", "Sand Dunes"] },
      { day: "Day 06", destination: "Jodhpur & Udaipur", image: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=400&q=80", text: "Morning in the Blue City — explore the sky-scraping Mehrangarh Fort and exclusive access to the Umaid Bhawan Palace. Afternoon arrival in Udaipur: a private boat across Lake Pichola to the legendary Lake Palace.", tags: ["Mehrangarh Fort", "Umaid Bhawan", "Lake Palace"] },
      { day: "Day 07", destination: "Mumbai", image: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=400&q=80", text: "Disembark at Mumbai CSMT. A final farewell brunch at a heritage Raj-era ballroom before transfers to the airport, carrying memories of a truly imperial odyssey.", tags: ["Farewell Brunch", "Heritage Ballroom", "Disembarkation"] }
    ],
    // NOTE: Maharajas' Express actually has 4 cabin tiers: Deluxe Cabin, Junior Suite, Suite, and Presidential Suite.
    // Prices below are indicative for the Indian Splendour itinerary (2024-25 season).
    pricing: [
      { tier: "Deluxe Cabin", inr: "₹6,51,000", usd: "$7,950", featured: false, features: ["Twin deluxe berth", "All meals & beverages", "Guided excursions", "Welcome gift", "24hr steward"] },
      { tier: "Suite", inr: "₹12,17,160", usd: "$14,870", featured: true, features: ["Full suite", "Private dining", "Dedicated butler", "Exclusive excursions", "Spa & wellness", "Private car transfers"] },

      { tier: "Junior Suite", inr: "₹8,34,960", usd: "$10,200", featured: false, features: ["Expansive junior suite", "Premium dining & bar", "Private guide", "Exclusive palace dinners", "Spa & wellness", "Dedicated butler"] },
      { tier: "Presidential Suite", inr: "₹20,90,760", usd: "$25,550", featured: false, features: ["Entire carriage suite", "Private chef & dining", "Personalized butler", "Exclusive reserve access", "Helicopter transfers", "Royal wardrobes"] }
    ]
  }
};

function applyTheme(colors) {
  const root = document.documentElement;
  root.style.setProperty('--train-primary', colors.primary);
  root.style.setProperty('--train-accent', colors.accent);
  root.style.setProperty('--train-border', colors.border);
  root.style.setProperty('--train-muted-bg', colors.mutedBg);
}

function getFeatureIcon(text) {
  const t = text.toLowerCase();
  if (t.includes('cabin') || t.includes('suite') || t.includes('berth')) return 'fa-bed';
  if (t.includes('meal') || t.includes('dining') || t.includes('food')) return 'fa-utensils';
  if (t.includes('tour') || t.includes('excursion') || t.includes('walk') || t.includes('guided')) return 'fa-map-location-dot';
  if (t.includes('welcome') || t.includes('gift')) return 'fa-gift';
  if (t.includes('butler') || t.includes('steward') || t.includes('concierge')) return 'fa-bell-concierge';
  if (t.includes('bar') || t.includes('beverage') || t.includes('tea')) return 'fa-glass-cheers';
  if (t.includes('spa') || t.includes('wellness') || t.includes('meditation')) return 'fa-spa';
  if (t.includes('transfer') || t.includes('car')) return 'fa-car-side';
  if (t.includes('helicopter')) return 'fa-helicopter';
  if (t.includes('temple') || t.includes('pilgrim') || t.includes('gopuram')) return 'fa-gopuram';
  if (t.includes('private') || t.includes('exclusive')) return 'fa-user-shield';
  if (t.includes('chef')) return 'fa-hat-chef';
  if (t.includes('royal') || t.includes('rajah') || t.includes('palace')) return 'fa-crown';
  if (t.includes('access')) return 'fa-key';
  if (t.includes('hospitality')) return 'fa-heart';
  if (t.includes('journey') || t.includes('train')) return 'fa-train-subway';
  if (t.includes('spiritual')) return 'fa-om';
  if (t.includes('monk') || t.includes('peace')) return 'fa-peace';
  if (t.includes('safari') || t.includes('tiger') || t.includes('wildlife')) return 'fa-paw';
  if (t.includes('award')) return 'fa-award';
  return 'fa-circle-check';
}

function renderPanel(trainKey) {
  const d = luxuryTrainData[trainKey];
  const priceCount = d.pricing.length;

  // Dynamic columns based on price card count
  let infoCol = "col-lg-4";
  let priceCol = "col-lg-8";

  if (priceCount <= 2) {
    infoCol = "col-lg-5";
    priceCol = "col-lg-7";
  } else if (priceCount >= 4) {
    infoCol = "col-lg-3";
    priceCol = "col-lg-9";
  }

  const isPriceSwiper = priceCount > 3;
  const pricingHTML = d.pricing.map(p => `
    <div class="${isPriceSwiper ? 'swiper-slide' : ''}">
      <div class="lux-price-card ${p.featured ? 'featured' : ''}" ${isPriceSwiper ? 'style="height:100%"' : ''}>
        ${p.featured ? `<span class="lux-featured-badge">Most Popular</span>` : ''}
        <div class="lux-price-tier">${p.tier}</div>
        <div class="lux-price-inr">${p.inr}</div>
        <div class="lux-price-usd">${p.usd} per person</div>
        <ul class="lux-price-features">
          ${p.features.map(f => `<li><i class="fa-solid ${getFeatureIcon(f)}"></i> ${f}</li>`).join('')}
        </ul>
        <button class="lux-btn-primary" style="width:100%;font-size:12px">Book This Suite</button>
      </div>
    </div>
  `).join('');

  const finalPricingContainer = isPriceSwiper
    ? `<div class="swiper lux-price-swiper" id="price-swiper-${trainKey}"><div class="swiper-wrapper">${pricingHTML}</div></div>`
    : `<div class="lux-pricing-grid" style="flex: 1;">${pricingHTML}</div>`;

  const slidesHTML = d.itinerary.map(day => `
    <div class="swiper-slide lux-slide">
      <div class="lux-slide-img">
        <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 220 260'%3E%3Crect width='220' height='260' fill='%23f9f5e6'/%3E%3C/svg%3E" 
             data-query="${day.destination} india travel" 
             alt="${day.destination}" 
             loading="lazy" 
             class="lux-dynamic-img">
      </div>
      <div class="lux-slide-content">
        <div>
          <div class="lux-slide-day">${day.day}</div>
          <div class="lux-slide-dest">${day.destination}</div>
          <div class="lux-slide-text">${day.text}</div>
        </div>
        <div class="lux-tags">${day.tags.map(t => `<span class="lux-tag">${t}</span>`).join('')}</div>
      </div>
    </div>
  `).join('');

  return `
    <div class="lux-train-panel active" id="panel-${trainKey}">
      <div class="row g-lg-4 g-3 align-items-stretch">

        <!-- Top Left: Info Card -->
        <div class="${infoCol}">
          <div class="lux-info-card h-100">
            <div class="lux-card-img-wrap">
              <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 300'%3E%3Crect width='400' height='300' fill='%23f9f5e6'/%3E%3C/svg%3E" 
                   data-query="${d.title} luxury train india interior" 
                   alt="${d.title}" 
                   loading="lazy"
                   class="lux-dynamic-img w-100"
                   style="aspect-ratio: 4/3; object-fit: cover;">
              <span class="lux-card-badge">${d.duration}</span>
            </div>
            <div class="lux-card-body">
              <div class="lux-card-title">${d.title}</div>
              <div class="lux-card-subtitle mb-3">
                <span>✦ ${d.subtitle}</span>
              </div>
              <div class="lux-card-desc" style="-webkit-line-clamp: 4; display: -webkit-box; -webkit-box-orient: vertical; overflow: hidden;">${d.description}</div>
            </div>
          </div>
        </div>

        <!-- Top Right: Pricing -->
        <div class="${priceCol}">
          <div class="lux-pricing-wrap h-100 d-flex flex-column">
            <div class="lux-right-label mt-0 mb-3">Suite Pricing</div>
            <div style="flex: 1;">${finalPricingContainer}</div>
          </div>
        </div>
      </div>
      <div class="lux-card-route my-5 mx-auto">
        <span class="lux-route-label"><i class="fa-solid fa-route"></i> Route:</span>
        <span class="lux-route-path">${d.route.split(' → ').join('<i class="fa-solid fa-chevron-right lux-route-arrow"></i>')}</span>
      </div>
        <!-- Bottom: Full Width Swiper -->
        <div class="col-12">
          <div class="lux-itinerary-header mt-4">
            <div class="lux-right-label">Day-by-Day Itinerary</div>
            <div class="lux-nav-group">
              <div class="swiper-pagination"></div>
              <div class="swiper-button-prev"></div>
              <div class="swiper-button-next"></div>
            </div>
          </div>
          <div class="lux-swiper-wrap">
            <div class="swiper lux-swiper" id="swiper-${trainKey}" style="width: 100%;">
              <div class="swiper-wrapper">${slidesHTML}</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  `;
}

let activeSwiper = null;
let activePriceSwiper = null;

function initSwiper(trainKey) {
  // 1. Itinerary Swiper
  if (activeSwiper) { activeSwiper.destroy(true, true); activeSwiper = null; }
  activeSwiper = new Swiper(`#swiper-${trainKey}`, {
    loop: true,
    spaceBetween: 12,
    autoplay: { delay: 4200, disableOnInteraction: false },
    navigation: {
      nextEl: `#panel-${trainKey} .swiper-button-next`,
      prevEl: `#panel-${trainKey} .swiper-button-prev`
    },
    pagination: {
      el: `#panel-${trainKey} .swiper-pagination`,
      clickable: true
    },
    breakpoints: {
      0: { slidesPerView: 1.2, spaceBetween: 10 },
      576: { slidesPerView: 2.2, spaceBetween: 15 },
      1024: { slidesPerView: 3, spaceBetween: 20 },
      1200: { slidesPerView: 4, spaceBetween: 20 },
      1400: { slidesPerView: 5, spaceBetween: 20 }
    }
  });

  // 2. Pricing Swiper (if > 3 cards)
  const d = luxuryTrainData[trainKey];
  if (d.pricing.length > 3) {
    if (activePriceSwiper) { activePriceSwiper.destroy(true, true); activePriceSwiper = null; }
    activePriceSwiper = new Swiper(`#price-swiper-${trainKey}`, {
      slidesPerView: 3,
      spaceBetween: 16,
      loop: true,
      autoplay: { delay: 3500, disableOnInteraction: false },
      breakpoints: {
        0: { slidesPerView: 1.1, spaceBetween: 10 },
        576: { slidesPerView: 2.1, spaceBetween: 12 },
        1024: { slidesPerView: 3, spaceBetween: 16 }
      }
    });
  }
}

/**
 * Fetches and updates all images with data-query attributes
 */
async function updateLuxImages() {
  const dynamicImages = document.querySelectorAll('.lux-dynamic-img[data-query]');

  dynamicImages.forEach(async (img) => {
    const query = img.getAttribute('data-query');
    if (!query) return;

    try {
      // fetchPexelsImage is globally available from adotrip.js
      const imageUrl = await fetchPexelsImage(query);
      if (imageUrl) {
        img.src = imageUrl;
        img.classList.add('loaded');
        // Remove attribute to avoid re-fetching if we switch back
        img.removeAttribute('data-query');
      }
    } catch (error) {
      console.error('Error updating luxury image:', error);
    }
  });
}

function switchTrain(trainKey) {
  const d = luxuryTrainData[trainKey];
  applyTheme(d.color);

  const sectionEl = document.getElementById('lux-trains-section');
  if (sectionEl) {
    sectionEl.style.backgroundColor = d.color.mutedBg;
  }

  const panelsEl = document.getElementById('luxPanels');
  panelsEl.innerHTML = renderPanel(trainKey);

  document.querySelectorAll('.lux-tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.train === trainKey);
    if (btn.dataset.train === trainKey) {
      btn.style.background = d.color.primary;
      btn.style.color = '#fff';
    } else {
      btn.style.background = '';
      btn.style.color = '';
    }
  });

  // Update Header Logos
  document.querySelectorAll('.lux-train-logo').forEach(logo => {
    logo.classList.toggle('active', logo.id === `logo-${trainKey}`);
  });

  // Fetch images asynchronously
  updateLuxImages();

  setTimeout(() => initSwiper(trainKey), 60);
}

document.getElementById('luxTabs').addEventListener('click', e => {
  const btn = e.target.closest('.lux-tab-btn');
  if (btn) switchTrain(btn.dataset.train);
});

switchTrain('goldenChariot');



// Luxury Highlights List
// Uncomment this section if you want to show feature highlights
// inside each luxury card.
//
// Insert Position:
// → Check line 176 for placement
//
// Requirements:
// - d.highlights should be an array
// - getFeatureIcon(h) should return a valid Font Awesome icon class

/*
<ul class="lux-highlights">
  ${d.highlights.map(h => `
    <li>
      <i class="fa-solid ${getFeatureIcon(h)}"></i>
      ${h}
    </li>
  `).join('')}
</ul>
*/